export const endPoints = {
    auth:{
        login: "/login",
        register: "/register"
    },
    cms:{
        create:"/createcontact",
        all_doctor_department:"/alldoctordepartment",
        appointment:"/createappointment",
        doctor_by_dept:"/departmentidwisedoctor",
        featured:"/featured",
        details:"/doctordetails",
        personalcare:"/personalcare",
        childcare:"/childcare",
        alldepartment:"/alldepartment",
        allblog:"/allblog",
        singleblog:"/singleblog",
        comment:"/createblogcomment",
        recentblog:"/recentblog",
        dashboard:"/userdash"
    }
};

export const endPointsPath =[
    endPoints.auth.login, endPoints.auth.register, 
    endPoints.cms.Create, endPoints.cms.all_doctor_department, 
    endPoints.cms.appointment, endPoints.cms.doctor_by_dept,
    endPoints.cms.featured, endPoints.cms.details,
    endPoints.cms.personalcare,endPoints.cms.childcare,
    endPoints.cms.alldepartment,endPoints.cms.allblog,endPoints.cms.singleblog,
    endPoints.cms.comment,endPoints.cms.recentblog,endPoints.cms.dashboard
]
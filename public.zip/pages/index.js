import Image from "next/image";
import { Inter } from "next/font/google";
import img1 from '../public/Images/about.jpg';
const inter = Inter({ subsets: ["latin"] });
import styles from '../styles/Home.module.css';
import { Box, Button } from "@mui/material";
import Link from "next/link";
import { Cookies } from "react-cookie";
import {Carousel} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

export default function Home() {

  const cookie = new Cookies();
  const token = cookie.get('token');

  return (
    <>
        <div>
          
             <Carousel indicators={false} fade={true} interval={2000}>
      <Carousel.Item>
      <img style={{height:"500px"}}
          className="d-block w-100 carousel-image"
          src="Images/hero.jpg" 
          alt="Second slide"
          
        />
        <Carousel.Caption>
          <h1 style={{fontSize:'80px',color:'#ff0157'}}>Welcome To Medioca</h1>
          <h2 style={{fontSize:'50px',color:'#f2ed57'}}>Best Healthcare Solution In Your City</h2>
          {token == null && (
            <Link style={{alignItems:"center" }} href={`/auth/login`}>
              <Button
                variant="contained"
                color="warning"
                size="large"
              >
                To Explore Us Please Login
              </Button>
            </Link>
          )}
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <img style={{height:"500px"}}
          className="d-block w-100 carousel-image"
          src= "Images/bgg2.webp" 
          alt="Second slide"
        />
        <Carousel.Caption>
        <h1 style={{fontSize:'80px',color:'#ff0157'}}>Welcome To Medioca</h1>
        <h2 style={{fontSize:'50px',color:'#f2ed57'}}>24/7 best Emergency Services Your City</h2>
        {token == null && (
            <Link style={{alignItems:"center" }} href={`/auth/login`}>
              <Button
                variant="contained"
                color="warning"
                size="large"
              >
                To Explore Us Please Login
              </Button>
            </Link>
          )}
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <img style={{height:"500px"}}
          className="d-block w-100 carousel-image"
          src="Images/bgg4.webp" 
          alt="Second slide"
        />
        <Carousel.Caption>
        <h1 style={{fontSize:'80px',color:'#ff0157'}}>Welcome To Medioca</h1>
        <h2 style={{fontSize:'50px',color:'#f2ed57'}}>Modern, Advanced Medical Equipment</h2>
        {token == null && (
            <Link style={{alignItems:"center" }} href={`/auth/login`}>
              <Button
                variant="contained"
                color="warning"
                size="large"
              >
                To Explore Us Please Login
              </Button>
            </Link>
          )}
        </Carousel.Caption>
        
      </Carousel.Item>
    </Carousel>
              

        </div>

      {/* <div className={styles.background}>
        <div >
          <h1 className={styles.text} >Welcome To Medioca</h1>
          <p className={styles.text1}>Best Healthcare <br /> Solution In Your City</p>
          {token == null && (
            <Link style={{ marginLeft: "200px" }} href={`/auth/login`}>
              <Button
                variant="contained"
                color="success"
                size="large"
              >
                To Explore Us Please Login
              </Button>
            </Link>
          )}
        </div>
      </div> */}
      {/* <Image  style={{width:'100%',height:'600px'}}
        src={img1}
        alt="Background Image"
        layout=""
        objectFit="cover"
      /> */}
      <div>
        <div className={styles.card}>
          <div className={styles.Section}>
            <img
              src="/Images/about.jpg"
              alt="Description"
              className={styles.image}
            />
          </div>
          <div className={styles.Section}>
            <h1>About Us</h1>
            <h2>Best Medical Care For <br /> Yourself and Your Family</h2>
            <p>Tempor erat elitr at rebum at at clita aliquyam consetetur.Diam dolor diam ipsum et, tempor voluptua sit consetetur sit. Aliquyam diam amet diam et eos sadipscing labore. Clita erat ipsum et lorem et sit, sed stet no labore lorem sit. Sanctus clita duo justo et tempor consetetur takimata eirmod</p>
            <Link href={`/cms/create`}>
              <Button
                variant="contained"
                color="secondary"
                size="large"
              >
                Contact With Us
              </Button>
            </Link>
          </div>
        </div>
        <div className={styles.section3}>
          <h1 className={styles.text4}>Our Super Specialities</h1>

          <Box style={{display: "flex", justifyContent: "space-around"}}>
            <Link style={{marginTop:"100px"}} href={`/cms/featured`}>
              <Button
                variant="contained"
                color="secondary"
                size="large"
              >
                featured
              </Button>
            </Link>
            <Link style={{marginTop:"100px"}} href={`/cms/alldoctor`}>
              <Button
                variant="contained"
                color="secondary"
                size="large"
              >
                alldoctor
              </Button>
            </Link>
            <Link style={{marginTop:"100px"}} href={`/cms/alldept`}>
              <Button
                variant="contained"
                color="secondary"
                size="large"
              >
                All Departments

              </Button>
            </Link>
          </Box>

        </div>
        <div className={styles.section2}>
          <h1 className={styles.text2}>Welcome to Our Blog</h1>
          <h2 className={styles.text3}>Bringing You the Latest in Healthcare and Wellbeing</h2>
          <Link style={{ paddingLeft: "580px" }} href={`/cms/allblog`}>
            <Button
              variant="contained"
              color="secondary"
              size="large"
            >
              Our Blog
            </Button>
          </Link>
        </div>

      </div>


    </>
  );
}

/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "__barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!./node_modules/@mui/material/index.js":
/*!******************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!./node_modules/@mui/material/index.js ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Box: () => (/* reexport default from dynamic */ _Box__WEBPACK_IMPORTED_MODULE_0___default.a),\n/* harmony export */   Container: () => (/* reexport default from dynamic */ _Container__WEBPACK_IMPORTED_MODULE_1___default.a),\n/* harmony export */   Grid: () => (/* reexport default from dynamic */ _Grid__WEBPACK_IMPORTED_MODULE_2___default.a),\n/* harmony export */   IconButton: () => (/* reexport default from dynamic */ _IconButton__WEBPACK_IMPORTED_MODULE_3___default.a),\n/* harmony export */   Typography: () => (/* reexport default from dynamic */ _Typography__WEBPACK_IMPORTED_MODULE_4___default.a)\n/* harmony export */ });\n/* harmony import */ var _Box__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Box */ \"./node_modules/@mui/material/node/Box/index.js\");\n/* harmony import */ var _Box__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_Box__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Container */ \"./node_modules/@mui/material/node/Container/index.js\");\n/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Container__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _Grid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Grid */ \"./node_modules/@mui/material/node/Grid/index.js\");\n/* harmony import */ var _Grid__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Grid__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _IconButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./IconButton */ \"./node_modules/@mui/material/node/IconButton/index.js\");\n/* harmony import */ var _IconButton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_IconButton__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Typography */ \"./node_modules/@mui/material/node/Typography/index.js\");\n/* harmony import */ var _Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Typography__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1Cb3gsQ29udGFpbmVyLEdyaWQsSWNvbkJ1dHRvbixUeXBvZ3JhcGh5IT0hLi9ub2RlX21vZHVsZXMvQG11aS9tYXRlcmlhbC9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ3NDO0FBQ1k7QUFDVjtBQUNZIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLy4vbm9kZV9tb2R1bGVzL0BtdWkvbWF0ZXJpYWwvaW5kZXguanM/Zjg4ZSJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQm94IH0gZnJvbSBcIi4vQm94XCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgQ29udGFpbmVyIH0gZnJvbSBcIi4vQ29udGFpbmVyXCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgR3JpZCB9IGZyb20gXCIuL0dyaWRcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBJY29uQnV0dG9uIH0gZnJvbSBcIi4vSWNvbkJ1dHRvblwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIFR5cG9ncmFwaHkgfSBmcm9tIFwiLi9UeXBvZ3JhcGh5XCIiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!./node_modules/@mui/material/index.js\n");

/***/ }),

/***/ "__barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js":
/*!***********************************************************************************************************************!*\
  !*** __barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Facebook: () => (/* reexport safe */ _Facebook__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Instagram: () => (/* reexport safe */ _Instagram__WEBPACK_IMPORTED_MODULE_1__[\"default\"]),\n/* harmony export */   LinkedIn: () => (/* reexport safe */ _LinkedIn__WEBPACK_IMPORTED_MODULE_2__[\"default\"]),\n/* harmony export */   Twitter: () => (/* reexport safe */ _Twitter__WEBPACK_IMPORTED_MODULE_3__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Facebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Facebook */ \"./node_modules/@mui/icons-material/esm/Facebook.js\");\n/* harmony import */ var _Instagram__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Instagram */ \"./node_modules/@mui/icons-material/esm/Instagram.js\");\n/* harmony import */ var _LinkedIn__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./LinkedIn */ \"./node_modules/@mui/icons-material/esm/LinkedIn.js\");\n/* harmony import */ var _Twitter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Twitter */ \"./node_modules/@mui/icons-material/esm/Twitter.js\");\n\n\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1GYWNlYm9vayxJbnN0YWdyYW0sTGlua2VkSW4sVHdpdHRlciE9IS4vbm9kZV9tb2R1bGVzL0BtdWkvaWNvbnMtbWF0ZXJpYWwvZXNtL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUNnRDtBQUNFO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9ub2RlX21vZHVsZXMvQG11aS9pY29ucy1tYXRlcmlhbC9lc20vaW5kZXguanM/ZTlkNiJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgRmFjZWJvb2sgfSBmcm9tIFwiLi9GYWNlYm9va1wiXG5leHBvcnQgeyBkZWZhdWx0IGFzIEluc3RhZ3JhbSB9IGZyb20gXCIuL0luc3RhZ3JhbVwiXG5leHBvcnQgeyBkZWZhdWx0IGFzIExpbmtlZEluIH0gZnJvbSBcIi4vTGlua2VkSW5cIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBUd2l0dGVyIH0gZnJvbSBcIi4vVHdpdHRlclwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js\n");

/***/ }),

/***/ "./public/Images/logo.jpg":
/*!********************************!*\
  !*** ./public/Images/logo.jpg ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\"src\":\"/_next/static/media/logo.976b1252.jpg\",\"height\":600,\"width\":600,\"blurDataURL\":\"/_next/image?url=%2F_next%2Fstatic%2Fmedia%2Flogo.976b1252.jpg&w=8&q=70\",\"blurWidth\":8,\"blurHeight\":8});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wdWJsaWMvSW1hZ2VzL2xvZ28uanBnIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxpRUFBZSxDQUFDLDRMQUE0TCIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3B1YmxpYy9JbWFnZXMvbG9nby5qcGc/MzZmNyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvbWVkaWEvbG9nby45NzZiMTI1Mi5qcGdcIixcImhlaWdodFwiOjYwMCxcIndpZHRoXCI6NjAwLFwiYmx1ckRhdGFVUkxcIjpcIi9fbmV4dC9pbWFnZT91cmw9JTJGX25leHQlMkZzdGF0aWMlMkZtZWRpYSUyRmxvZ28uOTc2YjEyNTIuanBnJnc9OCZxPTcwXCIsXCJibHVyV2lkdGhcIjo4LFwiYmx1ckhlaWdodFwiOjh9OyJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./public/Images/logo.jpg\n");

/***/ }),

/***/ "./Toolkit/authSlice.js":
/*!******************************!*\
  !*** ./Toolkit/authSlice.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   authSlice: () => (/* binding */ authSlice),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   logout: () => (/* binding */ logout)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-cookie */ \"react-cookie\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__, react_cookie__WEBPACK_IMPORTED_MODULE_1__]);\n([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__, react_cookie__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\nconst cookies = new react_cookie__WEBPACK_IMPORTED_MODULE_1__.Cookies();\nconst authSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({\n    name: \"auth\",\n    initialState: {},\n    reducers: {\n        logout (state, action) {\n            cookies.remove(\"token\", {\n                path: \"/\"\n            });\n            cookies.remove(\"image\", {\n                path: \"/\"\n            });\n            cookies.remove(\"name\", {\n                path: \"/\"\n            });\n            cookies.remove(\"_id\", {\n                path: \"/\"\n            });\n            console.log(\"Logout action called, cookies removed\");\n        }\n    }\n});\nconst { logout } = authSlice.actions;\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authSlice.reducer);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9Ub29sa2l0L2F1dGhTbGljZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUErQztBQUNSO0FBRXZDLE1BQU1FLFVBQVUsSUFBSUQsaURBQU9BO0FBRXBCLE1BQU1FLFlBQVlILDZEQUFXQSxDQUFDO0lBQ25DSSxNQUFNO0lBQ05DLGNBQWMsQ0FFZDtJQUNBQyxVQUFVO1FBQ1JDLFFBQU9DLEtBQUssRUFBRUMsTUFBTTtZQUNsQlAsUUFBUVEsTUFBTSxDQUFDLFNBQVM7Z0JBQUVDLE1BQU07WUFBSTtZQUNwQ1QsUUFBUVEsTUFBTSxDQUFDLFNBQVM7Z0JBQUVDLE1BQU07WUFBSTtZQUNwQ1QsUUFBUVEsTUFBTSxDQUFDLFFBQVE7Z0JBQUVDLE1BQU07WUFBSTtZQUNuQ1QsUUFBUVEsTUFBTSxDQUFDLE9BQU87Z0JBQUVDLE1BQU07WUFBSTtZQUNsQ0MsUUFBUUMsR0FBRyxDQUFDO1FBQ2Q7SUFDRjtBQUNGLEdBQUc7QUFFSSxNQUFNLEVBQUVOLE1BQU0sRUFBRSxHQUFHSixVQUFVVyxPQUFPLENBQUM7QUFDNUMsaUVBQWVYLFVBQVVZLE9BQU8sRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL1Rvb2xraXQvYXV0aFNsaWNlLmpzP2UwZDEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlU2xpY2UgfSBmcm9tIFwiQHJlZHV4anMvdG9vbGtpdFwiO1xyXG5pbXBvcnQgeyBDb29raWVzIH0gZnJvbSBcInJlYWN0LWNvb2tpZVwiO1xyXG5cclxuY29uc3QgY29va2llcyA9IG5ldyBDb29raWVzKCk7XHJcblxyXG5leHBvcnQgY29uc3QgYXV0aFNsaWNlID0gY3JlYXRlU2xpY2Uoe1xyXG4gIG5hbWU6IFwiYXV0aFwiLFxyXG4gIGluaXRpYWxTdGF0ZToge1xyXG4gICBcclxuICB9LFxyXG4gIHJlZHVjZXJzOiB7XHJcbiAgICBsb2dvdXQoc3RhdGUsIGFjdGlvbikge1xyXG4gICAgICBjb29raWVzLnJlbW92ZSgndG9rZW4nLCB7IHBhdGg6IFwiL1wiIH0pO1xyXG4gICAgICBjb29raWVzLnJlbW92ZShcImltYWdlXCIsIHsgcGF0aDogXCIvXCIgfSk7XHJcbiAgICAgIGNvb2tpZXMucmVtb3ZlKFwibmFtZVwiLCB7IHBhdGg6IFwiL1wiIH0pO1xyXG4gICAgICBjb29raWVzLnJlbW92ZShcIl9pZFwiLCB7IHBhdGg6IFwiL1wiIH0pO1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkxvZ291dCBhY3Rpb24gY2FsbGVkLCBjb29raWVzIHJlbW92ZWRcIik7XHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IHsgbG9nb3V0IH0gPSBhdXRoU2xpY2UuYWN0aW9ucztcclxuZXhwb3J0IGRlZmF1bHQgYXV0aFNsaWNlLnJlZHVjZXI7XHJcbiJdLCJuYW1lcyI6WyJjcmVhdGVTbGljZSIsIkNvb2tpZXMiLCJjb29raWVzIiwiYXV0aFNsaWNlIiwibmFtZSIsImluaXRpYWxTdGF0ZSIsInJlZHVjZXJzIiwibG9nb3V0Iiwic3RhdGUiLCJhY3Rpb24iLCJyZW1vdmUiLCJwYXRoIiwiY29uc29sZSIsImxvZyIsImFjdGlvbnMiLCJyZWR1Y2VyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./Toolkit/authSlice.js\n");

/***/ }),

/***/ "./Toolkit/store.js":
/*!**************************!*\
  !*** ./Toolkit/store.js ***!
  \**************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   persistor: () => (/* binding */ persistor),\n/* harmony export */   store: () => (/* binding */ store)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-persist */ \"redux-persist\");\n/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! redux-persist/lib/storage */ \"redux-persist/lib/storage\");\n/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _authSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./authSlice */ \"./Toolkit/authSlice.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__, _authSlice__WEBPACK_IMPORTED_MODULE_3__]);\n([_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__, _authSlice__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n // defaults to localStorage for web\n\n// Configuration for redux-persist\nconst persistConfig = {\n    key: \"root\",\n    storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2___default())\n};\nconst persistedReducer = (0,redux_persist__WEBPACK_IMPORTED_MODULE_1__.persistReducer)(persistConfig, _authSlice__WEBPACK_IMPORTED_MODULE_3__[\"default\"]);\nconst store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n    reducer: {\n        auth: persistedReducer\n    },\n    middleware: (getDefaultMiddleware)=>getDefaultMiddleware({\n            serializableCheck: false\n        })\n});\nconst persistor = (0,redux_persist__WEBPACK_IMPORTED_MODULE_1__.persistStore)(store);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9Ub29sa2l0L3N0b3JlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQWtEO0FBQ1c7QUFDYixDQUFDLG1DQUFtQztBQUNoRDtBQUVwQyxrQ0FBa0M7QUFDbEMsTUFBTUssZ0JBQWdCO0lBQ3BCQyxLQUFLO0lBQ0xILE9BQU9BLG9FQUFBQTtBQUNUO0FBRUEsTUFBTUksbUJBQW1CTCw2REFBY0EsQ0FBQ0csZUFBZUQsa0RBQVNBO0FBRXpELE1BQU1JLFFBQVFSLGdFQUFjQSxDQUFDO0lBQ2xDUyxTQUFTO1FBQ1BDLE1BQU1IO0lBQ1I7SUFDQUksWUFBWSxDQUFDQyx1QkFDWEEscUJBQXFCO1lBQ25CQyxtQkFBbUI7UUFDckI7QUFDSixHQUFHO0FBRUksTUFBTUMsWUFBWWIsMkRBQVlBLENBQUNPLE9BQU8iLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9Ub29sa2l0L3N0b3JlLmpzPzFmNGQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY29uZmlndXJlU3RvcmUgfSBmcm9tIFwiQHJlZHV4anMvdG9vbGtpdFwiO1xyXG5pbXBvcnQgeyBwZXJzaXN0U3RvcmUsIHBlcnNpc3RSZWR1Y2VyIH0gZnJvbSBcInJlZHV4LXBlcnNpc3RcIjtcclxuaW1wb3J0IHN0b3JhZ2UgZnJvbSBcInJlZHV4LXBlcnNpc3QvbGliL3N0b3JhZ2VcIjsgLy8gZGVmYXVsdHMgdG8gbG9jYWxTdG9yYWdlIGZvciB3ZWJcclxuaW1wb3J0IGF1dGhTbGljZSBmcm9tIFwiLi9hdXRoU2xpY2VcIjtcclxuXHJcbi8vIENvbmZpZ3VyYXRpb24gZm9yIHJlZHV4LXBlcnNpc3RcclxuY29uc3QgcGVyc2lzdENvbmZpZyA9IHtcclxuICBrZXk6IFwicm9vdFwiLFxyXG4gIHN0b3JhZ2UsXHJcbn07XHJcblxyXG5jb25zdCBwZXJzaXN0ZWRSZWR1Y2VyID0gcGVyc2lzdFJlZHVjZXIocGVyc2lzdENvbmZpZywgYXV0aFNsaWNlKTtcclxuXHJcbmV4cG9ydCBjb25zdCBzdG9yZSA9IGNvbmZpZ3VyZVN0b3JlKHtcclxuICByZWR1Y2VyOiB7XHJcbiAgICBhdXRoOiBwZXJzaXN0ZWRSZWR1Y2VyLFxyXG4gIH0sXHJcbiAgbWlkZGxld2FyZTogKGdldERlZmF1bHRNaWRkbGV3YXJlKSA9PlxyXG4gICAgZ2V0RGVmYXVsdE1pZGRsZXdhcmUoe1xyXG4gICAgICBzZXJpYWxpemFibGVDaGVjazogZmFsc2UsIC8vIERpc2FibGUgc2VyaWFsaXphYmxlIGNoZWNrIGZvciByZWR1eC1wZXJzaXN0IGFjdGlvbnNcclxuICAgIH0pLFxyXG59KTtcclxuXHJcbmV4cG9ydCBjb25zdCBwZXJzaXN0b3IgPSBwZXJzaXN0U3RvcmUoc3RvcmUpO1xyXG4iXSwibmFtZXMiOlsiY29uZmlndXJlU3RvcmUiLCJwZXJzaXN0U3RvcmUiLCJwZXJzaXN0UmVkdWNlciIsInN0b3JhZ2UiLCJhdXRoU2xpY2UiLCJwZXJzaXN0Q29uZmlnIiwia2V5IiwicGVyc2lzdGVkUmVkdWNlciIsInN0b3JlIiwicmVkdWNlciIsImF1dGgiLCJtaWRkbGV3YXJlIiwiZ2V0RGVmYXVsdE1pZGRsZXdhcmUiLCJzZXJpYWxpemFibGVDaGVjayIsInBlcnNpc3RvciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./Toolkit/store.js\n");

/***/ }),

/***/ "./api/axios/axios.js":
/*!****************************!*\
  !*** ./api/axios/axios.js ***!
  \****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   adminUrl: () => (/* binding */ adminUrl),\n/* harmony export */   baseURL: () => (/* binding */ baseURL),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   product: () => (/* binding */ product)\n/* harmony export */ });\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-cookie */ \"react-cookie\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, react_cookie__WEBPACK_IMPORTED_MODULE_1__]);\n([axios__WEBPACK_IMPORTED_MODULE_0__, react_cookie__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\nlet adminUrl = \"https://doctor-service.onrender.com\";\nconst baseURL = adminUrl;\nlet axiosInstance = axios__WEBPACK_IMPORTED_MODULE_0__[\"default\"].create({\n    baseURL\n});\nconst cookie = new react_cookie__WEBPACK_IMPORTED_MODULE_1__.Cookies();\n\nconst product = (media)=>{\n    return `https://doctor-service.onrender.com/${media}`;\n};\naxiosInstance.interceptors.request.use(async function(config) {\n    const token = cookie.get(\"token\");\n    if (token !== null || token !== undefined) {\n        config.headers[\"x-access-token\"] = token;\n    }\n    return config;\n}, function(err) {\n    return Promise.reject(err);\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosInstance);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9hcGkvYXhpb3MvYXhpb3MuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQTBCO0FBQ2E7QUFDdkMsSUFBSUUsV0FBVztBQUVSLE1BQU1DLFVBQVVELFNBQVM7QUFFaEMsSUFBSUUsZ0JBQWdCSixvREFBWSxDQUFDO0lBQy9CRztBQUNGO0FBQ0EsTUFBTUcsU0FBUyxJQUFJTCxpREFBT0E7QUFDTjtBQUViLE1BQU1NLFVBQVUsQ0FBQ0M7SUFDdEIsT0FBTyxDQUFDLG9DQUFvQyxFQUFFQSxNQUFNLENBQUM7QUFDdkQsRUFBRTtBQUVGSixjQUFjSyxZQUFZLENBQUNDLE9BQU8sQ0FBQ0MsR0FBRyxDQUNwQyxlQUFnQkMsTUFBTTtJQUNwQixNQUFNQyxRQUFPUCxPQUFPUSxHQUFHLENBQUM7SUFDeEIsSUFBSUQsVUFBVSxRQUFRQSxVQUFVRSxXQUFXO1FBQ3pDSCxPQUFPSSxPQUFPLENBQUMsaUJBQWlCLEdBQUdIO0lBQ3JDO0lBQ0EsT0FBT0Q7QUFDVCxHQUNBLFNBQVVLLEdBQUc7SUFDWCxPQUFPQyxRQUFRQyxNQUFNLENBQUNGO0FBQ3hCO0FBR0YsaUVBQWViLGFBQWFBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9hcGkvYXhpb3MvYXhpb3MuanM/YjRhMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IENvb2tpZXMgfSBmcm9tIFwicmVhY3QtY29va2llXCI7XHJcbmxldCBhZG1pblVybCA9IFwiaHR0cHM6Ly9kb2N0b3Itc2VydmljZS5vbnJlbmRlci5jb21cIjtcclxuXHJcbmV4cG9ydCBjb25zdCBiYXNlVVJMID0gYWRtaW5Vcmw7XHJcblxyXG5sZXQgYXhpb3NJbnN0YW5jZSA9IGF4aW9zLmNyZWF0ZSh7XHJcbiAgYmFzZVVSTCxcclxufSk7XHJcbmNvbnN0IGNvb2tpZSA9IG5ldyBDb29raWVzKCk7XHJcbmV4cG9ydCB7IGFkbWluVXJsIH07XHJcblxyXG5leHBvcnQgY29uc3QgcHJvZHVjdCA9IChtZWRpYSkgPT4ge1xyXG4gIHJldHVybiBgaHR0cHM6Ly9kb2N0b3Itc2VydmljZS5vbnJlbmRlci5jb20vJHttZWRpYX1gO1xyXG59O1xyXG5cclxuYXhpb3NJbnN0YW5jZS5pbnRlcmNlcHRvcnMucmVxdWVzdC51c2UoXHJcbiAgYXN5bmMgZnVuY3Rpb24gKGNvbmZpZykge1xyXG4gICAgY29uc3QgdG9rZW4gPWNvb2tpZS5nZXQoXCJ0b2tlblwiKVxyXG4gICAgaWYgKHRva2VuICE9PSBudWxsIHx8IHRva2VuICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgY29uZmlnLmhlYWRlcnNbXCJ4LWFjY2Vzcy10b2tlblwiXSA9IHRva2VuO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGNvbmZpZztcclxuICB9LFxyXG4gIGZ1bmN0aW9uIChlcnIpIHtcclxuICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnIpO1xyXG4gIH1cclxuKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGF4aW9zSW5zdGFuY2U7Il0sIm5hbWVzIjpbImF4aW9zIiwiQ29va2llcyIsImFkbWluVXJsIiwiYmFzZVVSTCIsImF4aW9zSW5zdGFuY2UiLCJjcmVhdGUiLCJjb29raWUiLCJwcm9kdWN0IiwibWVkaWEiLCJpbnRlcmNlcHRvcnMiLCJyZXF1ZXN0IiwidXNlIiwiY29uZmlnIiwidG9rZW4iLCJnZXQiLCJ1bmRlZmluZWQiLCJoZWFkZXJzIiwiZXJyIiwiUHJvbWlzZSIsInJlamVjdCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./api/axios/axios.js\n");

/***/ }),

/***/ "./layout/footer/index.jsx":
/*!*********************************!*\
  !*** ./layout/footer/index.jsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! __barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!@mui/material */ \"__barrel_optimize__?names=Box,Container,Grid,IconButton,Typography!=!./node_modules/@mui/material/index.js\");\n/* harmony import */ var _barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! __barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!@mui/icons-material */ \"__barrel_optimize__?names=Facebook,Instagram,LinkedIn,Twitter!=!./node_modules/@mui/icons-material/esm/index.js\");\n\n\n\n\n\nconst Footer = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"footer\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {\n            sx: {\n                bgcolor: \"#595959\",\n                color: \"whitesmoke\",\n                p: 6\n            },\n            component: \"footer\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Container, {\n                maxWidth: \"lg\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                    container: true,\n                    spacing: 4,\n                    justifyContent: \"space-between\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                            item: true,\n                            xs: 12,\n                            sm: 6,\n                            md: 3,\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                                    variant: \"h6\",\n                                    color: \"white\",\n                                    gutterBottom: true,\n                                    children: \"Site Links\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 14,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"./\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Home\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 17,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Products\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 20,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Add products\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 23,\n                                    columnNumber: 25\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                            lineNumber: 13,\n                            columnNumber: 21\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                            item: true,\n                            xs: 12,\n                            sm: 6,\n                            md: 3,\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                                    variant: \"h6\",\n                                    color: \"white\",\n                                    gutterBottom: true,\n                                    children: \"Quick Links\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 28,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Contact Us\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 31,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Privacy Policy\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 34,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {\n                                    href: \"#\",\n                                    variant: \"subtitle1\",\n                                    color: \"textSecondary\",\n                                    style: {\n                                        textDecoration: \"none\",\n                                        display: \"block\",\n                                        color: \"whitesmoke\"\n                                    },\n                                    children: \"Terms and Conditions\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 37,\n                                    columnNumber: 25\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                            lineNumber: 27,\n                            columnNumber: 21\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {\n                            item: true,\n                            xs: 12,\n                            sm: 6,\n                            md: 3,\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {\n                                    variant: \"h6\",\n                                    color: \"white\",\n                                    gutterBottom: true,\n                                    children: \"Follow Us\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 42,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                    href: \"#\",\n                                    color: \"inherit\",\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.Facebook, {}, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                        lineNumber: 46,\n                                        columnNumber: 29\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 45,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                    href: \"#\",\n                                    color: \"inherit\",\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.Twitter, {}, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                        lineNumber: 49,\n                                        columnNumber: 29\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 48,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                    href: \"#\",\n                                    color: \"inherit\",\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.Instagram, {}, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                        lineNumber: 52,\n                                        columnNumber: 29\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 51,\n                                    columnNumber: 25\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Box_Container_Grid_IconButton_Typography_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {\n                                    href: \"#\",\n                                    color: \"inherit\",\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Facebook_Instagram_LinkedIn_Twitter_mui_icons_material__WEBPACK_IMPORTED_MODULE_4__.LinkedIn, {}, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                        lineNumber: 55,\n                                        columnNumber: 29\n                                    }, undefined)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                                    lineNumber: 54,\n                                    columnNumber: 25\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                            lineNumber: 41,\n                            columnNumber: 21\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                    lineNumber: 12,\n                    columnNumber: 17\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n                lineNumber: 11,\n                columnNumber: 13\n            }, undefined)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n            lineNumber: 10,\n            columnNumber: 13\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\footer\\\\index.jsx\",\n        lineNumber: 8,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9sYXlvdXQvZm9vdGVyL2luZGV4LmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQTZCO0FBQ0g7QUFDbUQ7QUFDQTtBQUU3RSxNQUFNVyxTQUFTO0lBQ1gscUJBQ0ksOERBQUNDO2tCQUVHLDRFQUFDViw2R0FBR0E7WUFBQ1csSUFBSTtnQkFBRUMsU0FBUztnQkFBV0MsT0FBTTtnQkFBY0MsR0FBRztZQUFDO1lBQUdDLFdBQVU7c0JBQ3BFLDRFQUFDZCxtSEFBU0E7Z0JBQUNlLFVBQVM7MEJBQ2hCLDRFQUFDWiw4R0FBSUE7b0JBQUNhLFNBQVM7b0JBQUNDLFNBQVM7b0JBQUdDLGdCQUFlOztzQ0FDdkMsOERBQUNmLDhHQUFJQTs0QkFBQ2dCLElBQUk7NEJBQUNDLElBQUk7NEJBQUlDLElBQUk7NEJBQUdDLElBQUk7OzhDQUMxQiw4REFBQ3JCLG9IQUFVQTtvQ0FBQ3NCLFNBQVE7b0NBQUtYLE9BQU07b0NBQVFZLFlBQVk7OENBQUM7Ozs7Ozs4Q0FHcEQsOERBQUMzQixrREFBSUE7b0NBQUM0QixNQUFLO29DQUFLRixTQUFRO29DQUFZWCxPQUFNO29DQUFnQmMsT0FBTzt3Q0FBQ0MsZ0JBQWU7d0NBQU9DLFNBQVE7d0NBQVNoQixPQUFNO29DQUFZOzhDQUFHOzs7Ozs7OENBRzlILDhEQUFDZixrREFBSUE7b0NBQUM0QixNQUFLO29DQUFJRixTQUFRO29DQUFZWCxPQUFNO29DQUFnQmMsT0FBTzt3Q0FBQ0MsZ0JBQWU7d0NBQU9DLFNBQVE7d0NBQVNoQixPQUFNO29DQUFZOzhDQUFHOzs7Ozs7OENBRzdILDhEQUFDZixrREFBSUE7b0NBQUM0QixNQUFLO29DQUFJRixTQUFRO29DQUFZWCxPQUFNO29DQUFnQmMsT0FBTzt3Q0FBQ0MsZ0JBQWU7d0NBQU9DLFNBQVE7d0NBQVNoQixPQUFNO29DQUFZOzhDQUFHOzs7Ozs7Ozs7Ozs7c0NBSWpJLDhEQUFDVCw4R0FBSUE7NEJBQUNnQixJQUFJOzRCQUFDQyxJQUFJOzRCQUFJQyxJQUFJOzRCQUFHQyxJQUFJOzs4Q0FDMUIsOERBQUNyQixvSEFBVUE7b0NBQUNzQixTQUFRO29DQUFLWCxPQUFNO29DQUFRWSxZQUFZOzhDQUFDOzs7Ozs7OENBR3BELDhEQUFDM0Isa0RBQUlBO29DQUFDNEIsTUFBSztvQ0FBSUYsU0FBUTtvQ0FBWVgsT0FBTTtvQ0FBZ0JjLE9BQU87d0NBQUNDLGdCQUFlO3dDQUFPQyxTQUFRO3dDQUFTaEIsT0FBTTtvQ0FBWTs4Q0FBRzs7Ozs7OzhDQUc3SCw4REFBQ2Ysa0RBQUlBO29DQUFDNEIsTUFBSztvQ0FBSUYsU0FBUTtvQ0FBWVgsT0FBTTtvQ0FBZ0JjLE9BQU87d0NBQUNDLGdCQUFlO3dDQUFPQyxTQUFRO3dDQUFTaEIsT0FBTTtvQ0FBWTs4Q0FBRzs7Ozs7OzhDQUc3SCw4REFBQ2Ysa0RBQUlBO29DQUFDNEIsTUFBSztvQ0FBSUYsU0FBUTtvQ0FBWVgsT0FBTTtvQ0FBZ0JjLE9BQU87d0NBQUNDLGdCQUFlO3dDQUFPQyxTQUFRO3dDQUFTaEIsT0FBTTtvQ0FBWTs4Q0FBRzs7Ozs7Ozs7Ozs7O3NDQUlqSSw4REFBQ1QsOEdBQUlBOzRCQUFDZ0IsSUFBSTs0QkFBQ0MsSUFBSTs0QkFBSUMsSUFBSTs0QkFBR0MsSUFBSTs7OENBQzFCLDhEQUFDckIsb0hBQVVBO29DQUFDc0IsU0FBUTtvQ0FBS1gsT0FBTTtvQ0FBUVksWUFBWTs4Q0FBQzs7Ozs7OzhDQUdwRCw4REFBQ3RCLG9IQUFVQTtvQ0FBQ3VCLE1BQUs7b0NBQUliLE9BQU07OENBQ3ZCLDRFQUFDUixtSEFBUUE7Ozs7Ozs7Ozs7OENBRWIsOERBQUNGLG9IQUFVQTtvQ0FBQ3VCLE1BQUs7b0NBQUliLE9BQU07OENBQ3ZCLDRFQUFDUCxrSEFBT0E7Ozs7Ozs7Ozs7OENBRVosOERBQUNILG9IQUFVQTtvQ0FBQ3VCLE1BQUs7b0NBQUliLE9BQU07OENBQ3ZCLDRFQUFDTixvSEFBU0E7Ozs7Ozs7Ozs7OENBRWQsOERBQUNKLG9IQUFVQTtvQ0FBQ3VCLE1BQUs7b0NBQUliLE9BQU07OENBQ3ZCLDRFQUFDTCxtSEFBUUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFTckM7QUFFQSxpRUFBZUMsTUFBTUEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL2xheW91dC9mb290ZXIvaW5kZXguanN4PzJkZWYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSBcIm5leHQvbGlua1wiO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBCb3gsIENvbnRhaW5lciwgVHlwb2dyYXBoeSwgSWNvbkJ1dHRvbiwgR3JpZCB9IGZyb20gJ0BtdWkvbWF0ZXJpYWwnO1xyXG5pbXBvcnQgeyBGYWNlYm9vaywgVHdpdHRlciwgSW5zdGFncmFtLCBMaW5rZWRJbiB9IGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwnO1xyXG5cclxuY29uc3QgRm9vdGVyID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Zm9vdGVyPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPEJveCBzeD17eyBiZ2NvbG9yOiAnIzU5NTk1OScsIGNvbG9yOlwid2hpdGVzbW9rZVwiLCBwOiA2fX0gY29tcG9uZW50PVwiZm9vdGVyXCI+XHJcbiAgICAgICAgICAgIDxDb250YWluZXIgbWF4V2lkdGg9XCJsZ1wiPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgY29udGFpbmVyIHNwYWNpbmc9ezR9IGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbT17Nn0gbWQ9ezN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDZcIiBjb2xvcj1cIndoaXRlXCIgZ3V0dGVyQm90dG9tPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU2l0ZSBMaW5rc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIuL1wiIHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIiBjb2xvcj1cInRleHRTZWNvbmRhcnlcIiBzdHlsZT17e3RleHREZWNvcmF0aW9uOlwibm9uZVwiLGRpc3BsYXk6XCJibG9ja1wiLCBjb2xvcjpcIndoaXRlc21va2VcIn19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgSG9tZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdmFyaWFudD1cInN1YnRpdGxlMVwiIGNvbG9yPVwidGV4dFNlY29uZGFyeVwiIHN0eWxlPXt7dGV4dERlY29yYXRpb246XCJub25lXCIsZGlzcGxheTpcImJsb2NrXCIsIGNvbG9yOlwid2hpdGVzbW9rZVwifX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcm9kdWN0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdmFyaWFudD1cInN1YnRpdGxlMVwiIGNvbG9yPVwidGV4dFNlY29uZGFyeVwiIHN0eWxlPXt7dGV4dERlY29yYXRpb246XCJub25lXCIsZGlzcGxheTpcImJsb2NrXCIsIGNvbG9yOlwid2hpdGVzbW9rZVwifX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGQgcHJvZHVjdHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gc209ezZ9IG1kPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgY29sb3I9XCJ3aGl0ZVwiIGd1dHRlckJvdHRvbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFF1aWNrIExpbmtzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIiNcIiB2YXJpYW50PVwic3VidGl0bGUxXCIgY29sb3I9XCJ0ZXh0U2Vjb25kYXJ5XCIgc3R5bGU9e3t0ZXh0RGVjb3JhdGlvbjpcIm5vbmVcIixkaXNwbGF5OlwiYmxvY2tcIiwgY29sb3I6XCJ3aGl0ZXNtb2tlXCJ9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbnRhY3QgVXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIiBjb2xvcj1cInRleHRTZWNvbmRhcnlcIiBzdHlsZT17e3RleHREZWNvcmF0aW9uOlwibm9uZVwiLGRpc3BsYXk6XCJibG9ja1wiLCBjb2xvcjpcIndoaXRlc21va2VcIn19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpdmFjeSBQb2xpY3lcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIiBjb2xvcj1cInRleHRTZWNvbmRhcnlcIiBzdHlsZT17e3RleHREZWNvcmF0aW9uOlwibm9uZVwiLGRpc3BsYXk6XCJibG9ja1wiLCBjb2xvcjpcIndoaXRlc21va2VcIn19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVybXMgYW5kIENvbmRpdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gc209ezZ9IG1kPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg2XCIgY29sb3I9XCJ3aGl0ZVwiIGd1dHRlckJvdHRvbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZvbGxvdyBVc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGhyZWY9XCIjXCIgY29sb3I9XCJpbmhlcml0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFjZWJvb2sgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBocmVmPVwiI1wiIGNvbG9yPVwiaW5oZXJpdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFR3aXR0ZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBocmVmPVwiI1wiIGNvbG9yPVwiaW5oZXJpdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEluc3RhZ3JhbSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGhyZWY9XCIjXCIgY29sb3I9XCJpbmhlcml0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua2VkSW4gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvZm9vdGVyPlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZvb3RlcjsiXSwibmFtZXMiOlsiTGluayIsIlJlYWN0IiwiQm94IiwiQ29udGFpbmVyIiwiVHlwb2dyYXBoeSIsIkljb25CdXR0b24iLCJHcmlkIiwiRmFjZWJvb2siLCJUd2l0dGVyIiwiSW5zdGFncmFtIiwiTGlua2VkSW4iLCJGb290ZXIiLCJmb290ZXIiLCJzeCIsImJnY29sb3IiLCJjb2xvciIsInAiLCJjb21wb25lbnQiLCJtYXhXaWR0aCIsImNvbnRhaW5lciIsInNwYWNpbmciLCJqdXN0aWZ5Q29udGVudCIsIml0ZW0iLCJ4cyIsInNtIiwibWQiLCJ2YXJpYW50IiwiZ3V0dGVyQm90dG9tIiwiaHJlZiIsInN0eWxlIiwidGV4dERlY29yYXRpb24iLCJkaXNwbGF5Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./layout/footer/index.jsx\n");

/***/ }),

/***/ "./layout/header/index.jsx":
/*!*********************************!*\
  !*** ./layout/header/index.jsx ***!
  \*********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Header)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/material/AppBar */ \"@mui/material/AppBar\");\n/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/material/Box */ \"@mui/material/Box\");\n/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/material/Toolbar */ \"@mui/material/Toolbar\");\n/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/material/Typography */ \"@mui/material/Typography\");\n/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material/Button */ \"@mui/material/Button\");\n/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/material/IconButton */ \"@mui/material/IconButton\");\n/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7__);\n/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/icons-material/Menu */ \"@mui/icons-material/Menu\");\n/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_8__);\n/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/material/Container */ \"@mui/material/Container\");\n/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Container__WEBPACK_IMPORTED_MODULE_9__);\n/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/material/MenuItem */ \"@mui/material/MenuItem\");\n/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10__);\n/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @mui/material/Menu */ \"@mui/material/Menu\");\n/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Menu__WEBPACK_IMPORTED_MODULE_11__);\n/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @mui/material/Tooltip */ \"@mui/material/Tooltip\");\n/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12__);\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react-toastify */ \"react-toastify\");\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ \"./node_modules/react-toastify/dist/ReactToastify.css\");\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_14__);\n/* harmony import */ var _public_Images_logo_jpg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../public/Images/logo.jpg */ \"./public/Images/logo.jpg\");\n/* harmony import */ var _api_axios_axios__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/api/axios/axios */ \"./api/axios/axios.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_17__);\n/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react-cookie */ \"react-cookie\");\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! react-redux */ \"react-redux\");\n/* harmony import */ var _Toolkit_authSlice__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @/Toolkit/authSlice */ \"./Toolkit/authSlice.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_21__);\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! next/image */ \"./node_modules/next/image.js\");\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_22__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_13__, _api_axios_axios__WEBPACK_IMPORTED_MODULE_16__, react_cookie__WEBPACK_IMPORTED_MODULE_18__, react_redux__WEBPACK_IMPORTED_MODULE_19__, _Toolkit_authSlice__WEBPACK_IMPORTED_MODULE_20__]);\n([react_toastify__WEBPACK_IMPORTED_MODULE_13__, _api_axios_axios__WEBPACK_IMPORTED_MODULE_16__, react_cookie__WEBPACK_IMPORTED_MODULE_18__, react_redux__WEBPACK_IMPORTED_MODULE_19__, _Toolkit_authSlice__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n// const pages = [];\nconst settings = [\n    \"Register\"\n];\nfunction Header(request) {\n    const cookie = new react_cookie__WEBPACK_IMPORTED_MODULE_18__.Cookies();\n    const [anchorElNav, setAnchorElNav] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const [anchorElUser, setAnchorElUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const userId = cookie.get(\"_id\");\n    const token = cookie.get(\"token\");\n    const name = cookie.get(\"name\");\n    const image = cookie.get(\"image\");\n    const handleOpenNavMenu = (event)=>{\n        setAnchorElNav(event.currentTarget);\n    };\n    const handleOpenUserMenu = (event)=>{\n        setAnchorElUser(event.currentTarget);\n    };\n    const handleCloseNavMenu = ()=>{\n        setAnchorElNav(null);\n    };\n    const handleCloseUserMenu = ()=>{\n        setAnchorElUser(null);\n    };\n    // const handleChange = () => {\n    //   if (token !== null && token !== undefined) {\n    //     handleCloseUserMenu();\n    //     cookie.remove('token');\n    //     cookie.remove(\"image\");\n    //     cookie.remove(\"name\");\n    //     cookie.remove(\"_id\");\n    //     handleCloseUserMenu();\n    //     toast(\"Logged out successfully\");\n    //     //return NextResponse.redirect(new URL(\"/\", request.url));\n    //   }\n    //   else {\n    //     handleCloseUserMenu();\n    //     // return NextResponse.redirect(new URL(\"/auth/login\", request.url));\n    //   }\n    // }\n    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_19__.useDispatch)();\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_21__.useRouter)();\n    const handleLogout = ()=>{\n        dispatch((0,_Toolkit_authSlice__WEBPACK_IMPORTED_MODULE_20__.logout)());\n        router.push(\"/auth/login\");\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_2___default()), {\n        position: \"static\",\n        sx: {\n            backgroundColor: \"white\"\n        },\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Container__WEBPACK_IMPORTED_MODULE_9___default()), {\n            maxWidth: \"xl\",\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_4___default()), {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                lg: \"flex\",\n                                md: \"flex\",\n                                xs: \"none\"\n                            }\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_22___default()), {\n                                style: {\n                                    height: \"50px\",\n                                    width: \"50px\",\n                                    marginLeft: \"-10px\",\n                                    borderRadius: \"100px\"\n                                },\n                                src: _public_Images_logo_jpg__WEBPACK_IMPORTED_MODULE_15__[\"default\"],\n                                alt: \"Logo\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 88,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                                variant: \"h4\",\n                                noWrap: true,\n                                style: {\n                                    mr: 2,\n                                    display: {\n                                        xs: \"none\",\n                                        md: \"flex\"\n                                    },\n                                    fontFamily: \"Fantasy\",\n                                    fontWeight: 400,\n                                    letterSpacing: \".3rem\",\n                                    color: \"#3498db \",\n                                    textDecoration: \"none\",\n                                    marginTop: \"9px\",\n                                    marginLeft: \"50px\"\n                                },\n                                children: \"MEDIOCA\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 92,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                                sx: {\n                                    flexGrow: 1,\n                                    display: {\n                                        xs: \"none\",\n                                        md: \"flex\"\n                                    },\n                                    marginLeft: \"400px\",\n                                    display: \"flex\",\n                                    justifyContent: \"space-around\"\n                                },\n                                children: [\n                                    token && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_17___default()), {\n                                        style: {\n                                            marginTop: \"15px\",\n                                            textDecoration: \"none\"\n                                        },\n                                        href: `/`,\n                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                                            style: {\n                                                color: \"#3498db \"\n                                            },\n                                            children: \"HOME\"\n                                        }, void 0, false, {\n                                            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                            lineNumber: 112,\n                                            columnNumber: 17\n                                        }, this)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                        lineNumber: 111,\n                                        columnNumber: 15\n                                    }, this),\n                                    userId && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_17___default()), {\n                                        style: {\n                                            marginTop: \"15px\",\n                                            textDecoration: \"none\"\n                                        },\n                                        href: `/cms/dashboard/${userId}`,\n                                        passHref: true,\n                                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                                            style: {\n                                                color: \"#3498db \"\n                                            },\n                                            children: \"DASHBOARD\"\n                                        }, void 0, false, {\n                                            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                            lineNumber: 120,\n                                            columnNumber: 19\n                                        }, this)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                        lineNumber: 118,\n                                        columnNumber: 17\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 109,\n                                columnNumber: 13\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 85,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                xs: \"flex\",\n                                md: \"none\"\n                            }\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7___default()), {\n                                size: \"large\",\n                                \"aria-label\": \"account of current user\",\n                                \"aria-controls\": \"menu-appbar\",\n                                \"aria-haspopup\": \"true\",\n                                onClick: handleOpenNavMenu,\n                                color: \"inherit\",\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_8___default()), {}, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                    lineNumber: 138,\n                                    columnNumber: 15\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 130,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Menu__WEBPACK_IMPORTED_MODULE_11___default()), {\n                                id: \"menu-appbar\",\n                                anchorEl: anchorElNav,\n                                anchorOrigin: {\n                                    vertical: \"bottom\",\n                                    horizontal: \"left\"\n                                },\n                                keepMounted: true,\n                                transformOrigin: {\n                                    vertical: \"top\",\n                                    horizontal: \"left\"\n                                },\n                                open: Boolean(anchorElNav),\n                                onClose: handleCloseNavMenu,\n                                sx: {\n                                    display: {\n                                        xs: \"block\",\n                                        md: \"none\"\n                                    }\n                                }\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 140,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10___default()), {\n                                style: {\n                                    color: \"red\"\n                                },\n                                children: token !== null && token !== undefined ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                                    children: [\n                                        \"Hello.. \",\n                                        name\n                                    ]\n                                }, void 0, true) : \"\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 172,\n                                columnNumber: 13\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 129,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                lg: \"none\",\n                                md: \"none\",\n                                xs: \"block\"\n                            }\n                        }\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 179,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                        variant: \"h5\",\n                        sx: {\n                            mr: 2,\n                            display: {\n                                xs: \"flex\",\n                                md: \"none\"\n                            },\n                            flexGrow: 1,\n                            fontFamily: \"monospace\",\n                            fontWeight: 700,\n                            letterSpacing: \".3rem\",\n                            color: \"#3498db\",\n                            textDecoration: \"none\"\n                        },\n                        children: \"MEDIOCA\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 182,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 1,\n                            display: {\n                                xs: \"none\",\n                                md: \"flex\"\n                            }\n                        },\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10___default()), {\n                            style: {\n                                color: \"#ff0157\"\n                            },\n                            children: token !== null && token !== undefined ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                                children: [\n                                    \"Hello.. \",\n                                    name\n                                ]\n                            }, void 0, true) : \"\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                            lineNumber: 212,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 199,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_3___default()), {\n                        sx: {\n                            flexGrow: 0\n                        },\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12___default()), {\n                                title: \"Open settings\",\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_7___default()), {\n                                    onClick: handleOpenUserMenu,\n                                    sx: {\n                                        p: 0\n                                    },\n                                    children: token !== null && token !== undefined ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                                        style: {\n                                            width: \"50px\",\n                                            height: \"50px\",\n                                            borderRadius: \"100%\"\n                                        },\n                                        src: (0,_api_axios_axios__WEBPACK_IMPORTED_MODULE_16__.product)(image)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                        lineNumber: 222,\n                                        columnNumber: 59\n                                    }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                                        style: {\n                                            width: \"50px\",\n                                            height: \"50px\",\n                                            borderRadius: \"100%\"\n                                        },\n                                        src: \"/Images/login.jpg\"\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                        lineNumber: 223,\n                                        columnNumber: 22\n                                    }, this)\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                    lineNumber: 221,\n                                    columnNumber: 15\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 220,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Menu__WEBPACK_IMPORTED_MODULE_11___default()), {\n                                sx: {\n                                    mt: \"45px\"\n                                },\n                                id: \"menu-appbar\",\n                                anchorEl: anchorElUser,\n                                anchorOrigin: {\n                                    vertical: \"top\",\n                                    horizontal: \"right\"\n                                },\n                                keepMounted: true,\n                                transformOrigin: {\n                                    vertical: \"top\",\n                                    horizontal: \"right\"\n                                },\n                                open: Boolean(anchorElUser),\n                                onClose: handleCloseUserMenu,\n                                children: [\n                                    settings?.map((setting)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10___default()), {\n                                            onClick: handleCloseUserMenu,\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                                                textAlign: \"center\",\n                                                children: [\n                                                    \" \",\n                                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_17___default()), {\n                                                        href: `/auth/${setting.toLowerCase()}`,\n                                                        style: {\n                                                            textDecoration: \"none\",\n                                                            color: \"inherit\"\n                                                        },\n                                                        children: setting\n                                                    }, void 0, false, {\n                                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                                        lineNumber: 244,\n                                                        columnNumber: 51\n                                                    }, this)\n                                                ]\n                                            }, void 0, true, {\n                                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                                lineNumber: 244,\n                                                columnNumber: 19\n                                            }, this)\n                                        }, setting, false, {\n                                            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                            lineNumber: 243,\n                                            columnNumber: 17\n                                        }, this)),\n                                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_10___default()), {\n                                        onClick: handleLogout,\n                                        children: token !== null && token !== undefined ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_17___default()), {\n                                                href: `/auth/login`,\n                                                style: {\n                                                    textDecoration: \"none\",\n                                                    color: \"inherit\"\n                                                },\n                                                children: \" Logout\"\n                                            }, void 0, false, {\n                                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                                lineNumber: 257,\n                                                columnNumber: 21\n                                            }, this)\n                                        }, void 0, false) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_5___default()), {\n                                                textAlign: \"center\",\n                                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_17___default()), {\n                                                    href: `/auth/login`,\n                                                    style: {\n                                                        textDecoration: \"none\",\n                                                        color: \"inherit\"\n                                                    },\n                                                    children: \" Login\"\n                                                }, void 0, false, {\n                                                    fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                                    lineNumber: 264,\n                                                    columnNumber: 25\n                                                }, this)\n                                            }, void 0, false, {\n                                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                                lineNumber: 263,\n                                                columnNumber: 23\n                                            }, this)\n                                        }, void 0, false)\n                                    }, void 0, false, {\n                                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                        lineNumber: 252,\n                                        columnNumber: 15\n                                    }, this)\n                                ]\n                            }, void 0, true, {\n                                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                                lineNumber: 226,\n                                columnNumber: 13\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                        lineNumber: 219,\n                        columnNumber: 11\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n                lineNumber: 84,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n            lineNumber: 83,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\header\\\\index.jsx\",\n        lineNumber: 82,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9sYXlvdXQvaGVhZGVyL2luZGV4LmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBd0M7QUFDRTtBQUNOO0FBQ1E7QUFDTTtBQUNSO0FBQ1E7QUFDRjtBQUNBO0FBQ0Y7QUFDUjtBQUNNO0FBQ1c7QUFDUjtBQUNDO0FBQ0o7QUFDZjtBQUNVO0FBQ0c7QUFDRztBQUNMO0FBQ1Q7QUFFL0Isb0JBQW9CO0FBQ3BCLE1BQU11QixXQUFXO0lBQUM7Q0FBVztBQUVkLFNBQVNDLE9BQU9DLE9BQU87SUFDcEMsTUFBTUMsU0FBUyxJQUFJUixrREFBT0E7SUFFMUIsTUFBTSxDQUFDUyxhQUFhQyxlQUFlLEdBQUczQiwrQ0FBUUEsQ0FBQztJQUMvQyxNQUFNLENBQUM0QixjQUFjQyxnQkFBZ0IsR0FBRzdCLCtDQUFRQSxDQUFDO0lBRWpELE1BQU04QixTQUFTTCxPQUFPTSxHQUFHLENBQUM7SUFDMUIsTUFBTUMsUUFBUVAsT0FBT00sR0FBRyxDQUFDO0lBQ3pCLE1BQU1FLE9BQU9SLE9BQU9NLEdBQUcsQ0FBQztJQUN4QixNQUFNRyxRQUFRVCxPQUFPTSxHQUFHLENBQUM7SUFFekIsTUFBTUksb0JBQW9CLENBQUNDO1FBQ3pCVCxlQUFlUyxNQUFNQyxhQUFhO0lBQ3BDO0lBRUEsTUFBTUMscUJBQXFCLENBQUNGO1FBQzFCUCxnQkFBZ0JPLE1BQU1DLGFBQWE7SUFDckM7SUFFQSxNQUFNRSxxQkFBcUI7UUFDekJaLGVBQWU7SUFDakI7SUFFQSxNQUFNYSxzQkFBc0I7UUFDMUJYLGdCQUFnQjtJQUNsQjtJQUdBLCtCQUErQjtJQUMvQixpREFBaUQ7SUFDakQsNkJBQTZCO0lBQzdCLDhCQUE4QjtJQUM5Qiw4QkFBOEI7SUFDOUIsNkJBQTZCO0lBQzdCLDRCQUE0QjtJQUU1Qiw2QkFBNkI7SUFDN0Isd0NBQXdDO0lBQ3hDLGlFQUFpRTtJQUNqRSxNQUFNO0lBQ04sV0FBVztJQUdYLDZCQUE2QjtJQUM3Qiw0RUFBNEU7SUFDNUUsTUFBTTtJQUNOLElBQUk7SUFDSixNQUFNWSxXQUFXdkIseURBQVdBO0lBQzVCLE1BQU13QixTQUFTdEIsdURBQVNBO0lBQ3hCLE1BQU11QixlQUFlO1FBQ25CRixTQUFTdEIsMkRBQU1BO1FBQ2Z1QixPQUFPRSxJQUFJLENBQUM7SUFDZDtJQUVBLHFCQUNFLDhEQUFDM0MsNkRBQU1BO1FBQUM0QyxVQUFTO1FBQVNDLElBQUk7WUFBRUMsaUJBQWlCO1FBQVE7a0JBQ3ZELDRFQUFDdkMsZ0VBQVNBO1lBQUN3QyxVQUFTO3NCQUNsQiw0RUFBQzdDLDhEQUFPQTs7a0NBQ04sOERBQUNELDBEQUFHQTt3QkFBQzRDLElBQUk7NEJBQUVHLFVBQVU7NEJBQUdDLFNBQVM7Z0NBQUVDLElBQUk7Z0NBQVFDLElBQUk7Z0NBQVFDLElBQUk7NEJBQU87d0JBQUU7OzBDQUd0RSw4REFBQ2hDLG9EQUFLQTtnQ0FBQ2lDLE9BQU87b0NBQUVDLFFBQVE7b0NBQVFDLE9BQU87b0NBQVFDLFlBQVk7b0NBQVNDLGNBQWM7Z0NBQVE7Z0NBQ3hGQyxLQUFLN0MsZ0VBQUlBO2dDQUNUOEMsS0FBSTs7Ozs7OzBDQUVOLDhEQUFDeEQsaUVBQVVBO2dDQUNUeUQsU0FBUTtnQ0FDUkMsTUFBTTtnQ0FDTlIsT0FBTztvQ0FDTFMsSUFBSTtvQ0FDSmIsU0FBUzt3Q0FBRUcsSUFBSTt3Q0FBUUQsSUFBSTtvQ0FBTztvQ0FDbENZLFlBQVk7b0NBQ1pDLFlBQVk7b0NBQ1pDLGVBQWU7b0NBQ2ZDLE9BQU87b0NBQ1BDLGdCQUFnQjtvQ0FDaEJDLFdBQVc7b0NBQ1haLFlBQVk7Z0NBQ2Q7MENBQ0Q7Ozs7OzswQ0FHRCw4REFBQ3ZELDBEQUFHQTtnQ0FBQzRDLElBQUk7b0NBQUVHLFVBQVU7b0NBQUdDLFNBQVM7d0NBQUVHLElBQUk7d0NBQVFELElBQUk7b0NBQVE7b0NBQUdLLFlBQVk7b0NBQVNQLFNBQVE7b0NBQU9vQixnQkFBZTtnQ0FBZTs7b0NBQy9IdEMsdUJBQ0MsOERBQUNoQixtREFBSUE7d0NBQUNzQyxPQUFPOzRDQUFFZSxXQUFXOzRDQUFRRCxnQkFBZ0I7d0NBQU87d0NBQUdHLE1BQU0sQ0FBQyxDQUFDLENBQUM7a0RBQ25FLDRFQUFDbkUsaUVBQVVBOzRDQUFDa0QsT0FBTztnREFBQ2EsT0FBTzs0Q0FBVztzREFBRzs7Ozs7Ozs7Ozs7b0NBSzFDckMsd0JBQ0MsOERBQUNkLG1EQUFJQTt3Q0FBQ3NDLE9BQU87NENBQUVlLFdBQVc7NENBQVFELGdCQUFnQjt3Q0FBTzt3Q0FDdkRHLE1BQU0sQ0FBQyxlQUFlLEVBQUV6QyxPQUFPLENBQUM7d0NBQUUwQyxRQUFRO2tEQUMxQyw0RUFBQ3BFLGlFQUFVQTs0Q0FBQ2tELE9BQU87Z0RBQUNhLE9BQU87NENBQVc7c0RBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2tDQVNqRCw4REFBQ2pFLDBEQUFHQTt3QkFBQzRDLElBQUk7NEJBQUVHLFVBQVU7NEJBQUdDLFNBQVM7Z0NBQUVHLElBQUk7Z0NBQVFELElBQUk7NEJBQU87d0JBQUU7OzBDQUMxRCw4REFBQzlDLGlFQUFVQTtnQ0FDVG1FLE1BQUs7Z0NBQ0xDLGNBQVc7Z0NBQ1hDLGlCQUFjO2dDQUNkQyxpQkFBYztnQ0FDZEMsU0FBUzFDO2dDQUNUZ0MsT0FBTTswQ0FFTiw0RUFBQzVELGlFQUFRQTs7Ozs7Ozs7OzswQ0FFWCw4REFBQ0csNERBQUlBO2dDQUNIb0UsSUFBRztnQ0FDSEMsVUFBVXJEO2dDQUNWc0QsY0FBYztvQ0FDWkMsVUFBVTtvQ0FDVkMsWUFBWTtnQ0FDZDtnQ0FDQUMsV0FBVztnQ0FDWEMsaUJBQWlCO29DQUNmSCxVQUFVO29DQUNWQyxZQUFZO2dDQUNkO2dDQUNBRyxNQUFNQyxRQUFRNUQ7Z0NBQ2Q2RCxTQUFTaEQ7Z0NBQ1RPLElBQUk7b0NBQ0ZJLFNBQVM7d0NBQUVHLElBQUk7d0NBQVNELElBQUk7b0NBQU87Z0NBQ3JDOzs7Ozs7MENBZ0JGLDhEQUFDM0MsZ0VBQVFBO2dDQUFDNkMsT0FBTztvQ0FBRWEsT0FBTztnQ0FBTTswQ0FDN0JuQyxVQUFVLFFBQVFBLFVBQVV3RCwwQkFDM0I7O3dDQUFFO3dDQUFTdkQ7O21EQUVWOzs7Ozs7Ozs7Ozs7a0NBR1AsOERBQUMvQiwwREFBR0E7d0JBQUM0QyxJQUFJOzRCQUFFRyxVQUFVOzRCQUFHQyxTQUFTO2dDQUFFQyxJQUFJO2dDQUFRQyxJQUFJO2dDQUFRQyxJQUFJOzRCQUFRO3dCQUFFOzs7Ozs7a0NBR3pFLDhEQUFDakQsaUVBQVVBO3dCQUNUeUQsU0FBUTt3QkFFUmYsSUFBSTs0QkFDRmlCLElBQUk7NEJBQ0piLFNBQVM7Z0NBQUVHLElBQUk7Z0NBQVFELElBQUk7NEJBQU87NEJBQ2xDSCxVQUFVOzRCQUNWZSxZQUFZOzRCQUNaQyxZQUFZOzRCQUNaQyxlQUFlOzRCQUNmQyxPQUFPOzRCQUNQQyxnQkFBZ0I7d0JBQ2xCO2tDQUNEOzs7Ozs7a0NBSUQsOERBQUNsRSwwREFBR0E7d0JBQUM0QyxJQUFJOzRCQUFFRyxVQUFVOzRCQUFHQyxTQUFTO2dDQUFFRyxJQUFJO2dDQUFRRCxJQUFJOzRCQUFPO3dCQUFFO2tDQWExRCw0RUFBQzNDLGdFQUFRQTs0QkFBQzZDLE9BQU87Z0NBQUVhLE9BQU87NEJBQVU7c0NBQ2pDbkMsVUFBVSxRQUFRQSxVQUFVd0QsMEJBQzNCOztvQ0FBRTtvQ0FBU3ZEOzsrQ0FDWDs7Ozs7Ozs7Ozs7a0NBSU4sOERBQUMvQiwwREFBR0E7d0JBQUM0QyxJQUFJOzRCQUFFRyxVQUFVO3dCQUFFOzswQ0FDckIsOERBQUN0QywrREFBT0E7Z0NBQUM4RSxPQUFNOzBDQUNiLDRFQUFDbkYsaUVBQVVBO29DQUFDdUUsU0FBU3ZDO29DQUFvQlEsSUFBSTt3Q0FBRTRDLEdBQUc7b0NBQUU7OENBQ2pEMUQsVUFBVSxRQUFRQSxVQUFVd0QsMEJBQWEsOERBQUNHO3dDQUFJckMsT0FBTzs0Q0FBRUUsT0FBTzs0Q0FBUUQsUUFBUTs0Q0FBUUcsY0FBYzt3Q0FBTzt3Q0FBR0MsS0FBSzVDLDBEQUFPQSxDQUFDbUI7Ozs7OzZEQUN2SCw4REFBQ3lEO3dDQUFJckMsT0FBTzs0Q0FBRUUsT0FBTzs0Q0FBUUQsUUFBUTs0Q0FBUUcsY0FBYzt3Q0FBTzt3Q0FBR0MsS0FBSTs7Ozs7Ozs7Ozs7Ozs7OzswQ0FHbEYsOERBQUNqRCw0REFBSUE7Z0NBQ0hvQyxJQUFJO29DQUFFOEMsSUFBSTtnQ0FBTztnQ0FDakJkLElBQUc7Z0NBQ0hDLFVBQVVuRDtnQ0FDVm9ELGNBQWM7b0NBQ1pDLFVBQVU7b0NBQ1ZDLFlBQVk7Z0NBQ2Q7Z0NBQ0FDLFdBQVc7Z0NBQ1hDLGlCQUFpQjtvQ0FDZkgsVUFBVTtvQ0FDVkMsWUFBWTtnQ0FDZDtnQ0FDQUcsTUFBTUMsUUFBUTFEO2dDQUNkMkQsU0FBUy9DOztvQ0FFUmxCLFVBQVV1RSxJQUFJLENBQUNDLHdCQUNkLDhEQUFDckYsZ0VBQVFBOzRDQUFlb0UsU0FBU3JDO3NEQUMvQiw0RUFBQ3BDLGlFQUFVQTtnREFBQzJGLFdBQVU7O29EQUFTO2tFQUFDLDhEQUFDL0UsbURBQUlBO3dEQUFDdUQsTUFBTSxDQUFDLE1BQU0sRUFBRXVCLFFBQVFFLFdBQVcsR0FBRyxDQUFDO3dEQUFFMUMsT0FBTzs0REFBRWMsZ0JBQWdCOzREQUFRRCxPQUFPO3dEQUFVO2tFQUM3SDJCOzs7Ozs7Ozs7Ozs7MkNBRlVBOzs7OztrREFTakIsOERBQUNyRixnRUFBUUE7d0NBQUNvRSxTQUFTbEM7a0RBRWhCWCxVQUFVLFFBQVFBLFVBQVV3RCwwQkFDM0I7c0RBRUUsNEVBQUN4RSxtREFBSUE7Z0RBQUN1RCxNQUFNLENBQUMsV0FBVyxDQUFDO2dEQUFFakIsT0FBTztvREFBRWMsZ0JBQWdCO29EQUFRRCxPQUFPO2dEQUFVOzBEQUFHOzs7Ozs7MEVBS2hGO3NEQUNFLDRFQUFDL0QsaUVBQVVBO2dEQUFDMkYsV0FBVTswREFDcEIsNEVBQUMvRSxtREFBSUE7b0RBQUN1RCxNQUFNLENBQUMsV0FBVyxDQUFDO29EQUFFakIsT0FBTzt3REFBRWMsZ0JBQWdCO3dEQUFRRCxPQUFPO29EQUFVOzhEQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFleEciLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9sYXlvdXQvaGVhZGVyL2luZGV4LmpzeD80YTY5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEFwcEJhciBmcm9tICdAbXVpL21hdGVyaWFsL0FwcEJhcic7XHJcbmltcG9ydCBCb3ggZnJvbSAnQG11aS9tYXRlcmlhbC9Cb3gnO1xyXG5pbXBvcnQgVG9vbGJhciBmcm9tICdAbXVpL21hdGVyaWFsL1Rvb2xiYXInO1xyXG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tICdAbXVpL21hdGVyaWFsL1R5cG9ncmFwaHknO1xyXG5pbXBvcnQgQnV0dG9uIGZyb20gJ0BtdWkvbWF0ZXJpYWwvQnV0dG9uJztcclxuaW1wb3J0IEljb25CdXR0b24gZnJvbSAnQG11aS9tYXRlcmlhbC9JY29uQnV0dG9uJztcclxuaW1wb3J0IE1lbnVJY29uIGZyb20gJ0BtdWkvaWNvbnMtbWF0ZXJpYWwvTWVudSc7XHJcbmltcG9ydCBDb250YWluZXIgZnJvbSAnQG11aS9tYXRlcmlhbC9Db250YWluZXInO1xyXG5pbXBvcnQgTWVudUl0ZW0gZnJvbSAnQG11aS9tYXRlcmlhbC9NZW51SXRlbSc7XHJcbmltcG9ydCBNZW51IGZyb20gJ0BtdWkvbWF0ZXJpYWwvTWVudSc7XHJcbmltcG9ydCBUb29sdGlwIGZyb20gJ0BtdWkvbWF0ZXJpYWwvVG9vbHRpcCc7XHJcbmltcG9ydCB7IFRvYXN0Q29udGFpbmVyLCB0b2FzdCB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcclxuaW1wb3J0ICdyZWFjdC10b2FzdGlmeS9kaXN0L1JlYWN0VG9hc3RpZnkuY3NzJztcclxuaW1wb3J0IGltZzEgZnJvbSBcIi4uLy4uL3B1YmxpYy9JbWFnZXMvbG9nby5qcGdcIjtcclxuaW1wb3J0IHsgcHJvZHVjdCB9IGZyb20gJ0AvYXBpL2F4aW9zL2F4aW9zJztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuaW1wb3J0IHsgQ29va2llcyB9IGZyb20gJ3JlYWN0LWNvb2tpZSc7XHJcbmltcG9ydCB7IHVzZURpc3BhdGNoIH0gZnJvbSAncmVhY3QtcmVkdXgnO1xyXG5pbXBvcnQgeyBsb2dvdXQgfSBmcm9tICdAL1Rvb2xraXQvYXV0aFNsaWNlJztcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcblxyXG4vLyBjb25zdCBwYWdlcyA9IFtdO1xyXG5jb25zdCBzZXR0aW5ncyA9IFsnUmVnaXN0ZXInXTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhlYWRlcihyZXF1ZXN0KSB7XHJcbiAgY29uc3QgY29va2llID0gbmV3IENvb2tpZXMoKTtcclxuXHJcbiAgY29uc3QgW2FuY2hvckVsTmF2LCBzZXRBbmNob3JFbE5hdl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbYW5jaG9yRWxVc2VyLCBzZXRBbmNob3JFbFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IHVzZXJJZCA9IGNvb2tpZS5nZXQoJ19pZCcpO1xyXG4gIGNvbnN0IHRva2VuID0gY29va2llLmdldCgndG9rZW4nKTtcclxuICBjb25zdCBuYW1lID0gY29va2llLmdldChcIm5hbWVcIik7XHJcbiAgY29uc3QgaW1hZ2UgPSBjb29raWUuZ2V0KFwiaW1hZ2VcIik7XHJcblxyXG4gIGNvbnN0IGhhbmRsZU9wZW5OYXZNZW51ID0gKGV2ZW50KSA9PiB7XHJcbiAgICBzZXRBbmNob3JFbE5hdihldmVudC5jdXJyZW50VGFyZ2V0KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPcGVuVXNlck1lbnUgPSAoZXZlbnQpID0+IHtcclxuICAgIHNldEFuY2hvckVsVXNlcihldmVudC5jdXJyZW50VGFyZ2V0KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDbG9zZU5hdk1lbnUgPSAoKSA9PiB7XHJcbiAgICBzZXRBbmNob3JFbE5hdihudWxsKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDbG9zZVVzZXJNZW51ID0gKCkgPT4ge1xyXG4gICAgc2V0QW5jaG9yRWxVc2VyKG51bGwpO1xyXG4gIH07XHJcblxyXG5cclxuICAvLyBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoKSA9PiB7XHJcbiAgLy8gICBpZiAodG9rZW4gIT09IG51bGwgJiYgdG9rZW4gIT09IHVuZGVmaW5lZCkge1xyXG4gIC8vICAgICBoYW5kbGVDbG9zZVVzZXJNZW51KCk7XHJcbiAgLy8gICAgIGNvb2tpZS5yZW1vdmUoJ3Rva2VuJyk7XHJcbiAgLy8gICAgIGNvb2tpZS5yZW1vdmUoXCJpbWFnZVwiKTtcclxuICAvLyAgICAgY29va2llLnJlbW92ZShcIm5hbWVcIik7XHJcbiAgLy8gICAgIGNvb2tpZS5yZW1vdmUoXCJfaWRcIik7XHJcblxyXG4gIC8vICAgICBoYW5kbGVDbG9zZVVzZXJNZW51KCk7XHJcbiAgLy8gICAgIHRvYXN0KFwiTG9nZ2VkIG91dCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgLy8gICAgIC8vcmV0dXJuIE5leHRSZXNwb25zZS5yZWRpcmVjdChuZXcgVVJMKFwiL1wiLCByZXF1ZXN0LnVybCkpO1xyXG4gIC8vICAgfVxyXG4gIC8vICAgZWxzZSB7XHJcblxyXG5cclxuICAvLyAgICAgaGFuZGxlQ2xvc2VVc2VyTWVudSgpO1xyXG4gIC8vICAgICAvLyByZXR1cm4gTmV4dFJlc3BvbnNlLnJlZGlyZWN0KG5ldyBVUkwoXCIvYXV0aC9sb2dpblwiLCByZXF1ZXN0LnVybCkpO1xyXG4gIC8vICAgfVxyXG4gIC8vIH1cclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgZGlzcGF0Y2gobG9nb3V0KCkpO1xyXG4gICAgcm91dGVyLnB1c2goXCIvYXV0aC9sb2dpblwiKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPEFwcEJhciBwb3NpdGlvbj1cInN0YXRpY1wiIHN4PXt7IGJhY2tncm91bmRDb2xvcjogJ3doaXRlJyB9fT5cclxuICAgICAgPENvbnRhaW5lciBtYXhXaWR0aD1cInhsXCI+XHJcbiAgICAgICAgPFRvb2xiYXI+XHJcbiAgICAgICAgICA8Qm94IHN4PXt7IGZsZXhHcm93OiAxLCBkaXNwbGF5OiB7IGxnOiAnZmxleCcsIG1kOiAnZmxleCcsIHhzOiAnbm9uZScgfSB9fT5cclxuXHJcbiAgICAgICAgICAgIHsvKiA8aW1nIHN0eWxlPXt7d2lkdGg6XCIxMDBweFwiLCBoZWlnaHQ6XCI4MHB4XCIsZGlzcGxheTp7eHM6J25vbmUnLCBtZDonZmxleCd9fX0gc3JjPXtpbWcxfSBhbHQ9XCJcIiAvPiAgKi99XHJcbiAgICAgICAgICAgIDxJbWFnZSBzdHlsZT17eyBoZWlnaHQ6IFwiNTBweFwiLCB3aWR0aDogXCI1MHB4XCIsIG1hcmdpbkxlZnQ6IFwiLTEwcHhcIiwgYm9yZGVyUmFkaXVzOiBcIjEwMHB4XCIgfX1cclxuICAgICAgICAgICAgICBzcmM9e2ltZzF9XHJcbiAgICAgICAgICAgICAgYWx0PVwiTG9nb1wiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cImg0XCJcclxuICAgICAgICAgICAgICBub1dyYXBcclxuICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgbXI6IDIsXHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiB7IHhzOiAnbm9uZScsIG1kOiAnZmxleCcgfSxcclxuICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6ICdGYW50YXN5JyxcclxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDQwMCxcclxuICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6ICcuM3JlbScsXHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJyMzNDk4ZGIgJyxcclxuICAgICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uOiAnbm9uZScsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IFwiOXB4XCIsXHJcbiAgICAgICAgICAgICAgICBtYXJnaW5MZWZ0OiBcIjUwcHhcIlxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBNRURJT0NBXHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPEJveCBzeD17eyBmbGV4R3JvdzogMSwgZGlzcGxheTogeyB4czogJ25vbmUnLCBtZDogJ2ZsZXgnLCB9LCBtYXJnaW5MZWZ0OiBcIjQwMHB4XCIsIGRpc3BsYXk6XCJmbGV4XCIsanVzdGlmeUNvbnRlbnQ6XCJzcGFjZS1hcm91bmRcIix9fT5cclxuICAgICAgICAgICAge3Rva2VuICYmIChcclxuICAgICAgICAgICAgICA8TGluayBzdHlsZT17eyBtYXJnaW5Ub3A6IFwiMTVweFwiLCB0ZXh0RGVjb3JhdGlvbjogJ25vbmUnIH19IGhyZWY9e2AvYH0+XHJcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBzdHlsZT17e2NvbG9yOiAnIzM0OThkYiAnLH19PlxyXG4gICAgICAgICAgICAgICAgICBIT01FXHJcbiAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHt1c2VySWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPExpbmsgc3R5bGU9e3sgbWFyZ2luVG9wOiBcIjE1cHhcIiwgdGV4dERlY29yYXRpb246ICdub25lJyB9fVxyXG4gICAgICAgICAgICAgICAgICBocmVmPXtgL2Ntcy9kYXNoYm9hcmQvJHt1c2VySWR9YH0gcGFzc0hyZWY+XHJcbiAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHN0eWxlPXt7Y29sb3I6ICcjMzQ5OGRiICcsfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgREFTSEJPQVJEXHJcbiAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICA8Qm94IHN4PXt7IGZsZXhHcm93OiAxLCBkaXNwbGF5OiB7IHhzOiAnZmxleCcsIG1kOiAnbm9uZScgfSB9fT5cclxuICAgICAgICAgICAgPEljb25CdXR0b25cclxuICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJhY2NvdW50IG9mIGN1cnJlbnQgdXNlclwiXHJcbiAgICAgICAgICAgICAgYXJpYS1jb250cm9scz1cIm1lbnUtYXBwYmFyXCJcclxuICAgICAgICAgICAgICBhcmlhLWhhc3BvcHVwPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlT3Blbk5hdk1lbnV9XHJcbiAgICAgICAgICAgICAgY29sb3I9XCJpbmhlcml0XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxNZW51SWNvbiAvPlxyXG4gICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgIDxNZW51XHJcbiAgICAgICAgICAgICAgaWQ9XCJtZW51LWFwcGJhclwiXHJcbiAgICAgICAgICAgICAgYW5jaG9yRWw9e2FuY2hvckVsTmF2fVxyXG4gICAgICAgICAgICAgIGFuY2hvck9yaWdpbj17e1xyXG4gICAgICAgICAgICAgICAgdmVydGljYWw6ICdib3R0b20nLFxyXG4gICAgICAgICAgICAgICAgaG9yaXpvbnRhbDogJ2xlZnQnLFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAga2VlcE1vdW50ZWRcclxuICAgICAgICAgICAgICB0cmFuc2Zvcm1PcmlnaW49e3tcclxuICAgICAgICAgICAgICAgIHZlcnRpY2FsOiAndG9wJyxcclxuICAgICAgICAgICAgICAgIGhvcml6b250YWw6ICdsZWZ0JyxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIG9wZW49e0Jvb2xlYW4oYW5jaG9yRWxOYXYpfVxyXG4gICAgICAgICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlTmF2TWVudX1cclxuICAgICAgICAgICAgICBzeD17e1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogeyB4czogJ2Jsb2NrJywgbWQ6ICdub25lJyB9LFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7Lyoge3BhZ2VzLm1hcCgocGFnZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPE1lbnVJdGVtIGtleT17cGFnZX0gb25DbGljaz17aGFuZGxlQ2xvc2VOYXZNZW51fT5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHRleHRBbGlnbj1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e2AvY21zLyR7cGFnZS50b0xvd2VyQ2FzZSgpfWB9IHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiAnbm9uZScsIGNvbG9yOiAnIzM0OThkYiAgJyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgKSl9ICovfVxyXG5cclxuXHJcbiAgICAgICAgICAgIDwvTWVudT5cclxuICAgICAgICAgICAgPE1lbnVJdGVtIHN0eWxlPXt7IGNvbG9yOiBcInJlZFwiIH19PlxyXG4gICAgICAgICAgICAgIHt0b2tlbiAhPT0gbnVsbCAmJiB0b2tlbiAhPT0gdW5kZWZpbmVkID9cclxuICAgICAgICAgICAgICAgIDw+SGVsbG8uLiB7bmFtZX1cclxuICAgICAgICAgICAgICAgIDwvPiA6XHJcbiAgICAgICAgICAgICAgICAoXCJcIil9XHJcbiAgICAgICAgICAgIDwvTWVudUl0ZW0+XHJcbiAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgIDxCb3ggc3g9e3sgZmxleEdyb3c6IDEsIGRpc3BsYXk6IHsgbGc6ICdub25lJywgbWQ6ICdub25lJywgeHM6ICdibG9jaycgfSB9fT5cclxuICAgICAgICAgICAgey8qIDxpbWcgc3R5bGU9e3t3aWR0aDpcIjEzMHB4XCIsIGhlaWdodDpcIjEwMHB4XCJ9fSBzcmM9e2ltZzF9IGFsdD1cIlwiIC8+ICovfVxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgICB2YXJpYW50PVwiaDVcIlxyXG5cclxuICAgICAgICAgICAgc3g9e3tcclxuICAgICAgICAgICAgICBtcjogMixcclxuICAgICAgICAgICAgICBkaXNwbGF5OiB7IHhzOiAnZmxleCcsIG1kOiAnbm9uZScgfSxcclxuICAgICAgICAgICAgICBmbGV4R3JvdzogMSxcclxuICAgICAgICAgICAgICBmb250RmFtaWx5OiAnbW9ub3NwYWNlJyxcclxuICAgICAgICAgICAgICBmb250V2VpZ2h0OiA3MDAsXHJcbiAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogJy4zcmVtJyxcclxuICAgICAgICAgICAgICBjb2xvcjogJyMzNDk4ZGInLFxyXG4gICAgICAgICAgICAgIHRleHREZWNvcmF0aW9uOiAnbm9uZScsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIE1FRElPQ0FcclxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuXHJcbiAgICAgICAgICA8Qm94IHN4PXt7IGZsZXhHcm93OiAxLCBkaXNwbGF5OiB7IHhzOiAnbm9uZScsIG1kOiAnZmxleCcgfSB9fT5cclxuICAgICAgICAgICAgey8qIHtwYWdlcy5tYXAoKHBhZ2UpID0+IChcclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICBrZXk9e3BhZ2V9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbG9zZU5hdk1lbnV9XHJcbiAgICAgICAgICAgICAgICBzeD17eyBteTogMiwgY29sb3I6ICcjMzQ5OGRiICcsIGRpc3BsYXk6ICdibG9jaycgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8TGluayBocmVmPXtgL2Ntcy8ke3BhZ2UudG9Mb3dlckNhc2UoKX1gfSBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogJ25vbmUnLCBjb2xvcjogJyMzNDk4ZGIgICcgfX0+XHJcbiAgICAgICAgICAgICAgICAgIHtwYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgKSl9ICovfVxyXG4gICAgICAgICAgICA8TWVudUl0ZW0gc3R5bGU9e3sgY29sb3I6IFwiI2ZmMDE1N1wiIH19PlxyXG4gICAgICAgICAgICAgIHt0b2tlbiAhPT0gbnVsbCAmJiB0b2tlbiAhPT0gdW5kZWZpbmVkID9cclxuICAgICAgICAgICAgICAgIDw+SGVsbG8uLiB7bmFtZX08Lz4gOlxyXG4gICAgICAgICAgICAgICAgXCJcIn1cclxuICAgICAgICAgICAgPC9NZW51SXRlbT5cclxuICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgIDxCb3ggc3g9e3sgZmxleEdyb3c6IDAgfX0+XHJcbiAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiT3BlbiBzZXR0aW5nc1wiPlxyXG4gICAgICAgICAgICAgIDxJY29uQnV0dG9uIG9uQ2xpY2s9e2hhbmRsZU9wZW5Vc2VyTWVudX0gc3g9e3sgcDogMCB9fT5cclxuICAgICAgICAgICAgICAgIHt0b2tlbiAhPT0gbnVsbCAmJiB0b2tlbiAhPT0gdW5kZWZpbmVkID8gKDxpbWcgc3R5bGU9e3sgd2lkdGg6IFwiNTBweFwiLCBoZWlnaHQ6IFwiNTBweFwiLCBib3JkZXJSYWRpdXM6IFwiMTAwJVwiIH19IHNyYz17cHJvZHVjdChpbWFnZSl9IC8+KVxyXG4gICAgICAgICAgICAgICAgICA6ICg8aW1nIHN0eWxlPXt7IHdpZHRoOiBcIjUwcHhcIiwgaGVpZ2h0OiBcIjUwcHhcIiwgYm9yZGVyUmFkaXVzOiBcIjEwMCVcIiB9fSBzcmM9XCIvSW1hZ2VzL2xvZ2luLmpwZ1wiIC8+KX1cclxuICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgPE1lbnVcclxuICAgICAgICAgICAgICBzeD17eyBtdDogJzQ1cHgnIH19XHJcbiAgICAgICAgICAgICAgaWQ9XCJtZW51LWFwcGJhclwiXHJcbiAgICAgICAgICAgICAgYW5jaG9yRWw9e2FuY2hvckVsVXNlcn1cclxuICAgICAgICAgICAgICBhbmNob3JPcmlnaW49e3tcclxuICAgICAgICAgICAgICAgIHZlcnRpY2FsOiAndG9wJyxcclxuICAgICAgICAgICAgICAgIGhvcml6b250YWw6ICdyaWdodCcsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBrZWVwTW91bnRlZFxyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybU9yaWdpbj17e1xyXG4gICAgICAgICAgICAgICAgdmVydGljYWw6ICd0b3AnLFxyXG4gICAgICAgICAgICAgICAgaG9yaXpvbnRhbDogJ3JpZ2h0JyxcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIG9wZW49e0Jvb2xlYW4oYW5jaG9yRWxVc2VyKX1cclxuICAgICAgICAgICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZVVzZXJNZW51fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3NldHRpbmdzPy5tYXAoKHNldHRpbmcpID0+IChcclxuICAgICAgICAgICAgICAgIDxNZW51SXRlbSBrZXk9e3NldHRpbmd9IG9uQ2xpY2s9e2hhbmRsZUNsb3NlVXNlck1lbnV9PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB0ZXh0QWxpZ249XCJjZW50ZXJcIj4gPExpbmsgaHJlZj17YC9hdXRoLyR7c2V0dGluZy50b0xvd2VyQ2FzZSgpfWB9IHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiAnbm9uZScsIGNvbG9yOiAnaW5oZXJpdCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAge3NldHRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG5cclxuICAgICAgICAgICAgICAgIDwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgKSl9XHJcblxyXG4gICAgICAgICAgICAgIDxNZW51SXRlbSBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PlxyXG5cclxuICAgICAgICAgICAgICAgIHt0b2tlbiAhPT0gbnVsbCAmJiB0b2tlbiAhPT0gdW5kZWZpbmVkID8gKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXtgL2F1dGgvbG9naW5gfSBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogJ25vbmUnLCBjb2xvcjogJ2luaGVyaXQnIH19PiBMb2dvdXQ8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICA6XHJcbiAgICAgICAgICAgICAgICAgIChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdGV4dEFsaWduPVwiY2VudGVyXCIgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXtgL2F1dGgvbG9naW5gfSBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogJ25vbmUnLCBjb2xvcjogJ2luaGVyaXQnIH19PiBMb2dpbjwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgPC9NZW51SXRlbT5cclxuXHJcbiAgICAgICAgICAgIDwvTWVudT5cclxuICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvVG9vbGJhcj5cclxuICAgICAgPC9Db250YWluZXI+XHJcbiAgICA8L0FwcEJhcj5cclxuICApO1xyXG59XHJcblxyXG5cclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJBcHBCYXIiLCJCb3giLCJUb29sYmFyIiwiVHlwb2dyYXBoeSIsIkJ1dHRvbiIsIkljb25CdXR0b24iLCJNZW51SWNvbiIsIkNvbnRhaW5lciIsIk1lbnVJdGVtIiwiTWVudSIsIlRvb2x0aXAiLCJUb2FzdENvbnRhaW5lciIsInRvYXN0IiwiaW1nMSIsInByb2R1Y3QiLCJMaW5rIiwiQ29va2llcyIsInVzZURpc3BhdGNoIiwibG9nb3V0IiwidXNlUm91dGVyIiwiSW1hZ2UiLCJzZXR0aW5ncyIsIkhlYWRlciIsInJlcXVlc3QiLCJjb29raWUiLCJhbmNob3JFbE5hdiIsInNldEFuY2hvckVsTmF2IiwiYW5jaG9yRWxVc2VyIiwic2V0QW5jaG9yRWxVc2VyIiwidXNlcklkIiwiZ2V0IiwidG9rZW4iLCJuYW1lIiwiaW1hZ2UiLCJoYW5kbGVPcGVuTmF2TWVudSIsImV2ZW50IiwiY3VycmVudFRhcmdldCIsImhhbmRsZU9wZW5Vc2VyTWVudSIsImhhbmRsZUNsb3NlTmF2TWVudSIsImhhbmRsZUNsb3NlVXNlck1lbnUiLCJkaXNwYXRjaCIsInJvdXRlciIsImhhbmRsZUxvZ291dCIsInB1c2giLCJwb3NpdGlvbiIsInN4IiwiYmFja2dyb3VuZENvbG9yIiwibWF4V2lkdGgiLCJmbGV4R3JvdyIsImRpc3BsYXkiLCJsZyIsIm1kIiwieHMiLCJzdHlsZSIsImhlaWdodCIsIndpZHRoIiwibWFyZ2luTGVmdCIsImJvcmRlclJhZGl1cyIsInNyYyIsImFsdCIsInZhcmlhbnQiLCJub1dyYXAiLCJtciIsImZvbnRGYW1pbHkiLCJmb250V2VpZ2h0IiwibGV0dGVyU3BhY2luZyIsImNvbG9yIiwidGV4dERlY29yYXRpb24iLCJtYXJnaW5Ub3AiLCJqdXN0aWZ5Q29udGVudCIsImhyZWYiLCJwYXNzSHJlZiIsInNpemUiLCJhcmlhLWxhYmVsIiwiYXJpYS1jb250cm9scyIsImFyaWEtaGFzcG9wdXAiLCJvbkNsaWNrIiwiaWQiLCJhbmNob3JFbCIsImFuY2hvck9yaWdpbiIsInZlcnRpY2FsIiwiaG9yaXpvbnRhbCIsImtlZXBNb3VudGVkIiwidHJhbnNmb3JtT3JpZ2luIiwib3BlbiIsIkJvb2xlYW4iLCJvbkNsb3NlIiwidW5kZWZpbmVkIiwidGl0bGUiLCJwIiwiaW1nIiwibXQiLCJtYXAiLCJzZXR0aW5nIiwidGV4dEFsaWduIiwidG9Mb3dlckNhc2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./layout/header/index.jsx\n");

/***/ }),

/***/ "./layout/wrapper/wraper.jsx":
/*!***********************************!*\
  !*** ./layout/wrapper/wraper.jsx ***!
  \***********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../header */ \"./layout/header/index.jsx\");\n/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../footer */ \"./layout/footer/index.jsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_header__WEBPACK_IMPORTED_MODULE_2__]);\n_header__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\nconst Wrapper = ({ children })=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"flex flex-col min-h-screen\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_header__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\wrapper\\\\wraper.jsx\",\n                lineNumber: 8,\n                columnNumber: 14\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                className: \"flex-grow\",\n                children: children\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\wrapper\\\\wraper.jsx\",\n                lineNumber: 9,\n                columnNumber: 13\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_footer__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\wrapper\\\\wraper.jsx\",\n                lineNumber: 10,\n                columnNumber: 13\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\layout\\\\wrapper\\\\wraper.jsx\",\n        lineNumber: 7,\n        columnNumber: 9\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wrapper);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9sYXlvdXQvd3JhcHBlci93cmFwZXIuanN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQTBCO0FBQ0s7QUFDQTtBQUUvQixNQUFNRyxVQUFVLENBQUMsRUFBRUMsUUFBUSxFQUFFO0lBQ3pCLHFCQUNJLDhEQUFDQztRQUFJQyxXQUFVOzswQkFDViw4REFBQ0wsK0NBQU1BOzs7OzswQkFDUiw4REFBQ007Z0JBQUtELFdBQVU7MEJBQWFGOzs7Ozs7MEJBQzdCLDhEQUFDRiwrQ0FBTUE7Ozs7Ozs7Ozs7O0FBR25CO0FBRUEsaUVBQWVDLE9BQU9BLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9teS1hcHAvLi9sYXlvdXQvd3JhcHBlci93cmFwZXIuanN4P2I4ZWUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgSGVhZGVyIGZyb20gXCIuLi9oZWFkZXJcIjtcclxuaW1wb3J0IEZvb3RlciBmcm9tIFwiLi4vZm9vdGVyXCI7XHJcblxyXG5jb25zdCBXcmFwcGVyID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWluLWgtc2NyZWVuXCI+XHJcbiAgICAgICAgICAgICA8SGVhZGVyIC8+IFxyXG4gICAgICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LWdyb3dcIj57Y2hpbGRyZW59PC9tYWluPlxyXG4gICAgICAgICAgICA8Rm9vdGVyIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgV3JhcHBlcjtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwiSGVhZGVyIiwiRm9vdGVyIiwiV3JhcHBlciIsImNoaWxkcmVuIiwiZGl2IiwiY2xhc3NOYW1lIiwibWFpbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./layout/wrapper/wraper.jsx\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _layout_wrapper_wraper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/layout/wrapper/wraper */ \"./layout/wrapper/wraper.jsx\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _Toolkit_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/Toolkit/store */ \"./Toolkit/store.js\");\n/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @tanstack/react-query */ \"@tanstack/react-query\");\n/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-redux */ \"react-redux\");\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-toastify */ \"react-toastify\");\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ \"./node_modules/react-toastify/dist/ReactToastify.css\");\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_wrapper_wraper__WEBPACK_IMPORTED_MODULE_1__, _Toolkit_store__WEBPACK_IMPORTED_MODULE_3__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__, react_redux__WEBPACK_IMPORTED_MODULE_5__, react_toastify__WEBPACK_IMPORTED_MODULE_6__]);\n([_layout_wrapper_wraper__WEBPACK_IMPORTED_MODULE_1__, _Toolkit_store__WEBPACK_IMPORTED_MODULE_3__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__, react_redux__WEBPACK_IMPORTED_MODULE_5__, react_toastify__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\nconst queryClient = new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__.QueryClient();\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_4__.QueryClientProvider, {\n            client: queryClient,\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_redux__WEBPACK_IMPORTED_MODULE_5__.Provider, {\n                store: _Toolkit_store__WEBPACK_IMPORTED_MODULE_3__.store,\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_layout_wrapper_wraper__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                            ...pageProps\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\pages\\\\_app.js\",\n                            lineNumber: 17,\n                            columnNumber: 21\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\pages\\\\_app.js\",\n                        lineNumber: 16,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, {\n                        position: \"top-right\",\n                        autoClose: 5000,\n                        hideProgressBar: false,\n                        newestOnTop: false,\n                        closeOnClick: true,\n                        rtl: false,\n                        pauseOnFocusLoss: true,\n                        draggable: true,\n                        pauseOnHover: true\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\pages\\\\_app.js\",\n                        lineNumber: 19,\n                        columnNumber: 17\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\pages\\\\_app.js\",\n                lineNumber: 15,\n                columnNumber: 13\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\pages\\\\_app.js\",\n            lineNumber: 14,\n            columnNumber: 13\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\AYAN\\\\Desktop\\\\nextjs project 01\\\\my-app\\\\pages\\\\_app.js\",\n        lineNumber: 13,\n        columnNumber: 9\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDOEM7QUFDaEI7QUFDVTtBQUNpQztBQUNsQztBQUNnQjtBQUNOO0FBQ2pELE1BQU1PLGNBQWMsSUFBSUwsOERBQVdBO0FBRXBCLFNBQVNNLElBQUksRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDaEQscUJBQ0ksOERBQUNDO2tCQUNHLDRFQUFDUixzRUFBbUJBO1lBQUNTLFFBQVFMO3NCQUM3Qiw0RUFBQ0gsaURBQVFBO2dCQUFDSCxPQUFPQSxpREFBS0E7O2tDQUNsQiw4REFBQ0QsOERBQU9BO2tDQUNKLDRFQUFDUzs0QkFBVyxHQUFHQyxTQUFTOzs7Ozs7Ozs7OztrQ0FFNUIsOERBQUNMLDBEQUFjQTt3QkFDWFEsVUFBUzt3QkFDVEMsV0FBVzt3QkFDWEMsaUJBQWlCO3dCQUNqQkMsYUFBYTt3QkFDYkMsWUFBWTt3QkFDWkMsS0FBSzt3QkFDTEMsZ0JBQWdCO3dCQUNoQkMsU0FBUzt3QkFDVEMsWUFBWTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU1oQyIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCBXcmFwcGVyIGZyb20gXCJAL2xheW91dC93cmFwcGVyL3dyYXBlclwiO1xuaW1wb3J0IFwiQC9zdHlsZXMvZ2xvYmFscy5jc3NcIjtcbmltcG9ydCB7IHN0b3JlIH0gZnJvbSBcIkAvVG9vbGtpdC9zdG9yZVwiO1xuaW1wb3J0IHsgUXVlcnlDbGllbnQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xuaW1wb3J0IHsgVG9hc3RDb250YWluZXIsIHRvYXN0IH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuICBpbXBvcnQgJ3JlYWN0LXRvYXN0aWZ5L2Rpc3QvUmVhY3RUb2FzdGlmeS5jc3MnO1xuY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT5cbiAgICAgICAgICAgIDxQcm92aWRlciBzdG9yZT17c3RvcmV9PlxuICAgICAgICAgICAgICAgIDxXcmFwcGVyPlxuICAgICAgICAgICAgICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICAgICAgICAgICAgPC9XcmFwcGVyPlxuICAgICAgICAgICAgICAgIDxUb2FzdENvbnRhaW5lciBcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb249XCJ0b3AtcmlnaHRcIiBcbiAgICAgICAgICAgICAgICAgICAgYXV0b0Nsb3NlPXs1MDAwfSBcbiAgICAgICAgICAgICAgICAgICAgaGlkZVByb2dyZXNzQmFyPXtmYWxzZX0gXG4gICAgICAgICAgICAgICAgICAgIG5ld2VzdE9uVG9wPXtmYWxzZX0gXG4gICAgICAgICAgICAgICAgICAgIGNsb3NlT25DbGljayBcbiAgICAgICAgICAgICAgICAgICAgcnRsPXtmYWxzZX0gXG4gICAgICAgICAgICAgICAgICAgIHBhdXNlT25Gb2N1c0xvc3MgXG4gICAgICAgICAgICAgICAgICAgIGRyYWdnYWJsZSBcbiAgICAgICAgICAgICAgICAgICAgcGF1c2VPbkhvdmVyIFxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgIDwvUHJvdmlkZXI+XG4gICAgICAgICAgICA8L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXSwibmFtZXMiOlsiV3JhcHBlciIsInN0b3JlIiwiUXVlcnlDbGllbnQiLCJRdWVyeUNsaWVudFByb3ZpZGVyIiwiUHJvdmlkZXIiLCJUb2FzdENvbnRhaW5lciIsInRvYXN0IiwicXVlcnlDbGllbnQiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJkaXYiLCJjbGllbnQiLCJwb3NpdGlvbiIsImF1dG9DbG9zZSIsImhpZGVQcm9ncmVzc0JhciIsIm5ld2VzdE9uVG9wIiwiY2xvc2VPbkNsaWNrIiwicnRsIiwicGF1c2VPbkZvY3VzTG9zcyIsImRyYWdnYWJsZSIsInBhdXNlT25Ib3ZlciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@mui/icons-material/Menu":
/*!*******************************************!*\
  !*** external "@mui/icons-material/Menu" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ "@mui/material/AppBar":
/*!***************************************!*\
  !*** external "@mui/material/AppBar" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ "@mui/material/Box":
/*!************************************!*\
  !*** external "@mui/material/Box" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Box");

/***/ }),

/***/ "@mui/material/Button":
/*!***************************************!*\
  !*** external "@mui/material/Button" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Button");

/***/ }),

/***/ "@mui/material/Container":
/*!******************************************!*\
  !*** external "@mui/material/Container" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Container");

/***/ }),

/***/ "@mui/material/IconButton":
/*!*******************************************!*\
  !*** external "@mui/material/IconButton" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ "@mui/material/Menu":
/*!*************************************!*\
  !*** external "@mui/material/Menu" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Menu");

/***/ }),

/***/ "@mui/material/MenuItem":
/*!*****************************************!*\
  !*** external "@mui/material/MenuItem" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/MenuItem");

/***/ }),

/***/ "@mui/material/Toolbar":
/*!****************************************!*\
  !*** external "@mui/material/Toolbar" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ "@mui/material/Tooltip":
/*!****************************************!*\
  !*** external "@mui/material/Tooltip" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ "@mui/material/Typography":
/*!*******************************************!*\
  !*** external "@mui/material/Typography" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Typography");

/***/ }),

/***/ "@mui/material/utils":
/*!**************************************!*\
  !*** external "@mui/material/utils" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/utils");

/***/ }),

/***/ "@mui/system":
/*!******************************!*\
  !*** external "@mui/system" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system");

/***/ }),

/***/ "@mui/system/DefaultPropsProvider":
/*!***************************************************!*\
  !*** external "@mui/system/DefaultPropsProvider" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/DefaultPropsProvider");

/***/ }),

/***/ "@mui/system/InitColorSchemeScript":
/*!****************************************************!*\
  !*** external "@mui/system/InitColorSchemeScript" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/InitColorSchemeScript");

/***/ }),

/***/ "@mui/system/colorManipulator":
/*!***********************************************!*\
  !*** external "@mui/system/colorManipulator" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/colorManipulator");

/***/ }),

/***/ "@mui/system/createStyled":
/*!*******************************************!*\
  !*** external "@mui/system/createStyled" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createStyled");

/***/ }),

/***/ "@mui/system/createTheme":
/*!******************************************!*\
  !*** external "@mui/system/createTheme" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/createTheme");

/***/ }),

/***/ "@mui/system/styleFunctionSx":
/*!**********************************************!*\
  !*** external "@mui/system/styleFunctionSx" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/styleFunctionSx");

/***/ }),

/***/ "@mui/system/useThemeProps":
/*!********************************************!*\
  !*** external "@mui/system/useThemeProps" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/system/useThemeProps");

/***/ }),

/***/ "@mui/utils":
/*!*****************************!*\
  !*** external "@mui/utils" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils");

/***/ }),

/***/ "@mui/utils/capitalize":
/*!****************************************!*\
  !*** external "@mui/utils/capitalize" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/capitalize");

/***/ }),

/***/ "@mui/utils/chainPropTypes":
/*!********************************************!*\
  !*** external "@mui/utils/chainPropTypes" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/chainPropTypes");

/***/ }),

/***/ "@mui/utils/composeClasses":
/*!********************************************!*\
  !*** external "@mui/utils/composeClasses" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/composeClasses");

/***/ }),

/***/ "@mui/utils/deepmerge":
/*!***************************************!*\
  !*** external "@mui/utils/deepmerge" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/deepmerge");

/***/ }),

/***/ "@mui/utils/elementTypeAcceptingRef":
/*!*****************************************************!*\
  !*** external "@mui/utils/elementTypeAcceptingRef" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/elementTypeAcceptingRef");

/***/ }),

/***/ "@mui/utils/formatMuiErrorMessage":
/*!***************************************************!*\
  !*** external "@mui/utils/formatMuiErrorMessage" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/formatMuiErrorMessage");

/***/ }),

/***/ "@mui/utils/generateUtilityClass":
/*!**************************************************!*\
  !*** external "@mui/utils/generateUtilityClass" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClass");

/***/ }),

/***/ "@mui/utils/generateUtilityClasses":
/*!****************************************************!*\
  !*** external "@mui/utils/generateUtilityClasses" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/generateUtilityClasses");

/***/ }),

/***/ "@mui/utils/refType":
/*!*************************************!*\
  !*** external "@mui/utils/refType" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/refType");

/***/ }),

/***/ "@mui/utils/requirePropFactory":
/*!************************************************!*\
  !*** external "@mui/utils/requirePropFactory" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/requirePropFactory");

/***/ }),

/***/ "@mui/utils/useEventCallback":
/*!**********************************************!*\
  !*** external "@mui/utils/useEventCallback" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useEventCallback");

/***/ }),

/***/ "@mui/utils/useForkRef":
/*!****************************************!*\
  !*** external "@mui/utils/useForkRef" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useForkRef");

/***/ }),

/***/ "@mui/utils/useIsFocusVisible":
/*!***********************************************!*\
  !*** external "@mui/utils/useIsFocusVisible" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useIsFocusVisible");

/***/ }),

/***/ "@mui/utils/useTimeout":
/*!****************************************!*\
  !*** external "@mui/utils/useTimeout" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@mui/utils/useTimeout");

/***/ }),

/***/ "clsx":
/*!***********************!*\
  !*** external "clsx" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("clsx");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group":
/*!*****************************************!*\
  !*** external "react-transition-group" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "redux-persist":
/*!********************************!*\
  !*** external "redux-persist" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist");

/***/ }),

/***/ "redux-persist/lib/storage":
/*!********************************************!*\
  !*** external "redux-persist/lib/storage" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ "@reduxjs/toolkit":
/*!***********************************!*\
  !*** external "@reduxjs/toolkit" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = import("@reduxjs/toolkit");;

/***/ }),

/***/ "@tanstack/react-query":
/*!****************************************!*\
  !*** external "@tanstack/react-query" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ "react-cookie":
/*!*******************************!*\
  !*** external "react-cookie" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-cookie");;

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-redux");;

/***/ }),

/***/ "react-toastify":
/*!*********************************!*\
  !*** external "react-toastify" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/@mui","vendor-chunks/@babel","vendor-chunks/react-toastify"], () => (__webpack_exec__("./pages/_app.js")));
module.exports = __webpack_exports__;

})();